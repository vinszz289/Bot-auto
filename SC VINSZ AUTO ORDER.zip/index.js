;const { Telegraf, Markup, session } = require("telegraf");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const qs = require("querystring");
const FormData = require("form-data");
const archiver = require("archiver");
const QRCode = require("qrcode");
const config = require("./config");
const { createdQris, cekStatus, toRupiah } = require("./lib/payment");

const bot = new Telegraf(config.botToken);
bot.use(session());

const globalNokos = {
  cachedServices: [],
  cachedCountries: {},
  lastServicePhoto: {},
  activeOrders: {}
};

function isPrivateChat(ctx) {
  return ctx.chat.type === 'private';
}

async function requirePrivateChat(ctx, actionName) {
  if (!isPrivateChat(ctx)) {
    await ctx.answerCbQuery("❌ Perintah ini hanya bisa digunakan di Private Chat!", { show_alert: true });
    
    try {
      await ctx.reply("🔒 Silakan gunakan di Private Chat:", {
        reply_markup: {
          inline_keyboard: [
            [{ text: "💬 Chat Private", url: `https://t.me/${bot.botInfo.username}` }]
          ]
        }
      });
    } catch (e) {}
    
    return false;
  }
  return true;
}

async function sendProductNotification(type, productData, addedBy) {
  try {
    if (!config.testimoniChannel || !config.testimoniChannel.trim()) {
      console.log("[INFO] Channel testimoni belum diatur di config.js");
      return;
    }

    const channel = config.testimoniChannel;
    const timestamp = new Date().toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });

    let message = "";
    let inlineKeyboard = [];

    const escapeHTML = (text) => {
      if (!text) return "-";
      return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    };

    if (type === "script") {
      message = `🎉 <b>PRODUK BARU DITAMBAHKAN!</b>\n\n` +
                `📦 <b>TIPE:</b> 📁 SCRIPT\n` +
                `📛 <b>NAMA:</b> ${escapeHTML(productData.nama)}\n` +
                `💰 <b>HARGA:</b> ${toRupiah(productData.harga)}\n` +
                `📄 <b>FILE:</b> ${escapeHTML(productData.fileName || "-")}\n\n` +
                `👤 <b>DITAMBAHKAN OLEH:</b> ${escapeHTML(addedBy)}\n` +
                `🕒 <b>WAKTU:</b> ${escapeHTML(timestamp)}\n\n` +
                `🛒 <b>Beli sekarang di bot:</b> @${bot.botInfo.username}`;
      
      inlineKeyboard = [[
        { text: "🛒 Beli Script", url: `https://t.me/${bot.botInfo.username}?start=shop` }
      ]];
    } 
    else if (type === "app") {
      message = `🎉 <b>PRODUK BARU DITAMBAHKAN!</b>\n\n` +
                `📦 <b>TIPE:</b> 📱 APP SC BUG\n` +
                `📛 <b>NAMA:</b> ${escapeHTML(productData.nama)}\n` +
                `💰 <b>HARGA:</b> ${toRupiah(productData.harga)}\n` +
                `📝 <b>DESKRIPSI:</b> ${escapeHTML(productData.deskripsi || "-")}\n` +
                `📊 <b>STOK:</b> ${(productData.accounts || []).length} akun\n\n` +
                `👤 <b>DITAMBAHKAN OLEH:</b> ${escapeHTML(addedBy)}\n` +
                `🕒 <b>WAKTU:</b> ${escapeHTML(timestamp)}\n\n` +
                `🛒 <b>Beli sekarang di bot:</b> @${bot.botInfo.username}`;
      
      inlineKeyboard = [[
        { text: "🛒 Beli App", url: `https://t.me/${bot.botInfo.username}?start=shop` }
      ]];
    } 
    else if (type === "account") {
      message = `🎉 <b>STOK AKUN DITAMBAHKAN!</b>\n\n` +
                `📦 <b>UNTUK SC BUG:</b> ${escapeHTML(productData.appName)}\n` +
                `📝 <b>DESKRIPSI:</b> ${escapeHTML(productData.desc || "-")}\n\n` +
                `📊 <b>STOK SEKARANG:</b> ${productData.newStock} akun\n` +
                `👤 <b>DITAMBAHKAN OLEH:</b> ${escapeHTML(addedBy)}\n` +
                `🕒 <b>WAKTU:</b> ${escapeHTML(timestamp)}\n\n` +
                `🛒 <b>Beli sekarang di bot:</b> @${bot.botInfo.username}`;
      
      inlineKeyboard = [[
        { text: "🛒 Beli App", url: `https://t.me/${bot.botInfo.username}?start=shop` }
      ]];
    } 
    else {
      return;
    }

    console.log("[DEBUG] Sending notification to channel:", channel);
    console.log("[DEBUG] Message length:", message.length);

    await bot.telegram.sendMessage(channel, message, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: inlineKeyboard },
      disable_web_page_preview: true
    });

    console.log(`[NOTIF] Produk ${type} berhasil dikirim ke channel`);
    
  } catch (error) {
    console.error("[ERROR] Gagal mengirim notifikasi produk ke channel:", error.message);
    console.error("[ERROR] Stack:", error.stack);
  }
}

async function getDropletCount() {
  try {
    const apiDO = config.ApiDO1;
    if (!apiDO || apiDO === "-") return 0;

    const res = await axios.get("https://api.digitalocean.com/v2/droplets", {
      headers: { Authorization: `Bearer ${apiDO}` }
    });

    return res.data.droplets?.length || 0;
  } catch (e) {
    console.error("Error checking droplet count:", e.message);
    return 0;
  }
}

async function createVPSDroplet(userId, vpsData) {
  try {
    const apiDO = config.ApiDO1;
    if (!apiDO) {
      return { success: false, msg: "API KEY DigitalOcean tidak ditemukan!" };
    }

    const sizeMap = {
      "2c2": "s-2vcpu-2gb-amd",
      "4c2": "s-2vcpu-4gb-amd",
      "8c4": "s-4vcpu-8gb-amd",
      "16c4": "s-4vcpu-16gb-amd",
      "16c8": "s-8vcpu-16gb-amd"
    };

    const size = sizeMap[vpsData.plan];
    if (!size) {
      return { success: false, msg: "PLAN VPS TIDAK VALID!" };
    }

    const osShort = (vpsData.osFamily || "ubuntu").toLowerCase();
    const regionShort = (vpsData.region || "sgp1").toLowerCase();
    const planShort = (vpsData.plan || "2c2").toLowerCase();
    const urut = String(Math.floor(Math.random() * 90) + 10);
    const hostname = `${osShort}-${planShort}-${regionShort}-${urut}`;
    const password = "ZECHO#" + size.replace(/s-|-/g, "").toUpperCase();

    const payload = {
      name: hostname,
      region: vpsData.region,
      size: size,
      image: vpsData.os,
      ipv6: true,
      backups: false,
      tags: ["NRLSTUDIO-BuyVPS"],
      user_data: `#cloud-config
password: ${password}
chpasswd: { expire: False }`
    };

    console.log("Creating VPS with payload:", JSON.stringify(payload, null, 2));

    const resp = await axios.post("https://api.digitalocean.com/v2/droplets", payload, {
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiDO}`
      },
      timeout: 30000
    });

    if (resp.status !== 202) {
      return { success: false, msg: "Gagal membuat VPS: " + JSON.stringify(resp.data) };
    }

    const dropletId = resp.data.droplet.id;
    console.log(`VPS Created - ID: ${dropletId}, Hostname: ${hostname}`);

    await new Promise(r => setTimeout(r, 60000));

    const cek = await axios.get(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
      headers: { "Authorization": `Bearer ${apiDO}` },
      timeout: 10000
    });

    const dropletInfo = cek.data.droplet;
    const ip = dropletInfo?.networks?.v4?.[0]?.ip_address || "N/A";
    
    console.log(`VPS IP: ${ip}`);

    const vpsFolder = "./database";
    const vpsPath = `${vpsFolder}/data_vps.json`;

    if (!fs.existsSync(vpsFolder)) {
      fs.mkdirSync(vpsFolder, { recursive: true });
    }

    if (!fs.existsSync(vpsPath)) {
      fs.writeFileSync(vpsPath, JSON.stringify([], null, 2));
    }

    let vpsDB = [];
    try {
      vpsDB = JSON.parse(fs.readFileSync(vpsPath));
      if (!Array.isArray(vpsDB)) vpsDB = [];
    } catch (err) {
      vpsDB = [];
    }

    const created = new Date().toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });

    const paketInfo = {
      low: { garansi: 7, replace: 1 },
      medium: { garansi: 15, replace: 2 },
      high: { garansi: 30, replace: -1 }
    };

    const newVpsData = {
      userId: userId,
      username: vpsData.username || "-",
      hostname: hostname,
      ip: ip,
      password: password,
      region: vpsData.region,
      osFamily: vpsData.osFamily,
      os: vpsData.os,
      paket: vpsData.paket,
      plan: vpsData.plan,
      garansi: paketInfo[vpsData.paket]?.garansi || 7,
      replace: paketInfo[vpsData.paket]?.replace || 1,
      harga: vpsData.harga,
      dropletId: dropletId,
      created: created,
      penjual: bot.botInfo.username
    };

    vpsDB.push(newVpsData);
    fs.writeFileSync(vpsPath, JSON.stringify(vpsDB, null, 2));

    return {
      success: true,
      data: {
        hostname,
        ip,
        password,
        region: vpsData.region,
        os: vpsData.os,
        plan: vpsData.plan,
        garansi: paketInfo[vpsData.paket]?.garansi || 7,
        replace: paketInfo[vpsData.paket]?.replace || 1,
        created
      }
    };

  } catch (error) {
    console.error("Error creating VPS:", error);
    return { 
      success: false, 
      msg: error.response?.data?.message || error.message || "Unknown error" 
    };
  }
}

async function atlanticTransfer(nominal, config, note = "Withdraw Saldo Bot") {
  try {
    const reffId = `wd_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const body = {
      api_key: config.apiAtlantic,
      ref_id: reffId,
      kode_bank: config.wd_balance.bank_code,
      nomor_akun: config.wd_balance.destination_number,
      nama_pemilik: config.wd_balance.destination_name,
      nominal: Number(nominal),
      email: "bot@telegram.com",
      phone: config.wd_balance.destination_number,
      note: note
    };

    const response = await axios.post("https://atlantich2h.com/transfer/create", qs.stringify(body), {
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      timeout: 15000
    });

    return response.data;
  } catch (error) {
    throw new Error(`Gagal membuat transfer: ${error.message}`);
  }
}

async function rumahOtpTransfer(nominal, config) {
  try {
    const reffId = `wd_rotp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const body = {
      api_key: config.RUMAHOTP,
      action: 'transfer',
      code: config.wd_balance.bank_code,
      target: config.wd_balance.destination_number,
      amount: parseInt(nominal),
      reff_id: reffId
    };

    const response = await axios.post("https://www.rumahotp.com/api/v2/h2h/transfer", qs.stringify(body), {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      }
    });

    if (!response.data || (response.data.success === false)) {
        throw new Error(response.data.message || "Gagal request ke API RumahOTP");
    }

    return response.data;
  } catch (error) {
    throw new Error(`Gagal WD RumahOTP: ${error.message}`);
  }
}

async function atlanticTransferStatus(transferId, api_key) {
  const body = { api_key, id: String(transferId) };
  const response = await axios.post("https://atlantich2h.com/transfer/status", qs.stringify(body), {
    headers: { "Content-Type": "application/x-www-form-urlencoded" }
  });
  return response.data;
}

async function editMenuMessage(ctx, text, keyboard) {
  try {
    await ctx.editMessageText(text, {
      parse_mode: "HTML",
      ...keyboard
    });
  } catch (e) {
    try {
      const newMsg = await safeReply(ctx, text, {
        parse_mode: "HTML",
        ...keyboard
      });
      
      try {
        if (ctx.callbackQuery) {
          await ctx.deleteMessage();
        }
      } catch (err) {}
      
      return newMsg;
    } catch (replyErr) {
      console.error("Edit menu error:", replyErr);
      return null;
    }
  }
}

async function editMenuMessageWithPhoto(ctx, photo, caption, keyboard) {
  try {
    await ctx.editMessageMedia({
      type: 'photo',
      media: photo,
      caption: caption,
      parse_mode: 'HTML'
    }, {
      parse_mode: "HTML",
      ...keyboard
    });
  } catch (e) {
    try {
      try {
        if (ctx.callbackQuery) {
          await ctx.deleteMessage();
        }
      } catch (err) {}
      
      await ctx.replyWithPhoto(photo, {
        caption: caption,
        parse_mode: "HTML",
        ...keyboard
      });
    } catch (replyErr) {
      console.error("Edit menu with photo error:", replyErr);
      return null;
    }
  }
}

async function safeSend(method, chatId, ...args) {
  try {
    return await bot.telegram[method](chatId, ...args);
  } catch (err) {
    const m = err?.response?.description || err?.description || err?.message || String(err);
    if (typeof m === 'string' && (m.toLowerCase().includes('user is deactivated') || m.toLowerCase().includes('bot was blocked') || m.toLowerCase().includes('blocked'))) {
      return null;
    }
    throw err;
  }
}

async function safeReply(ctx, text, extra = {}) {
  try {
    return await ctx.reply(text, extra);
  } catch (err) {
    const m = err?.response?.description || err?.description || err?.message || String(err);
    if (typeof m === 'string' && (m.toLowerCase().includes('user is deactivated') || m.toLowerCase().includes('bot was blocked') || m.toLowerCase().includes('blocked'))) {
      return null;
    }
    throw err;
  }
}

const USERS_DB = "./users.json";
const DB_PATH = "./database.json";
const MANUAL_PAYMENTS_DB = "./manual_payments.json";
const activeTransactions = {};
const userState = {};
const liveChatState = {};
const ownerReplyState = {};

let botStartTime = Date.now();

const TESTIMONI_CHANNEL = config.testimoniChannel || "";

async function createAndSendFullBackup(ctx = null, isAuto = false) {
  const timestamp = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
    .replace(/[\/:]/g, '-').replace(/, /g, '_');
  
  const backupName = `SC_FULL_${config.botName || 'Bot'}_${timestamp}.zip`;
  const backupPath = path.join(__dirname, backupName);
  const output = fs.createWriteStream(backupPath);
  const archive = archiver('zip', { zlib: { level: 9 } });

  console.log(`[BACKUP] Memulai proses zip full SC...`);

  return new Promise((resolve, reject) => {
    output.on('close', async () => {
      try {
        const caption = isAuto 
          ? `♻️ <b>AUTO BACKUP SC</b>\n📅 ${timestamp}\n📦 Full Source Code (Tanpa node_modules)`
          : `📦 <b>BACKUP SOURCE CODE</b>\n📅 ${timestamp}\n✅ Full Folder Zip`;

        await bot.telegram.sendDocument(config.ownerId, {
          source: backupPath,
          filename: backupName
        }, { caption: caption, parse_mode: "HTML" });

        fs.unlinkSync(backupPath);
        if (ctx) await ctx.reply("✅ <b>Backup Full SC Terkirim!</b>", { parse_mode: "HTML" });
        resolve(true);
      } catch (err) {
        console.error("[BACKUP FAIL]", err);
        if (ctx) await ctx.reply("❌ Gagal kirim backup.");
        reject(err);
      }
    });

    archive.on('error', (err) => reject(err));
    archive.pipe(output);

    archive.glob('**/*', {
      cwd: __dirname,
      ignore: [
        'node_modules/**', 
        '.git/**',
        'package-lock.json',
        '*.zip',
        'session/**'
      ]
    });

    archive.finalize();
  });
}

async function generateLocalQr(qrString) {
  try {
    return await QRCode.toBuffer(qrString, {
      type: 'png',
      width: 400,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    });
  } catch (err) {
    console.error("QR Generate Error:", err);
    return null;
  }
}

async function sendStartInfoToChannel(user) {
  try {
    // LANGSUNG MASUKKIN ID CHANNEL LOG DI SINI BANG
    const ID_CHANNEL_LOG = '-1003596184701'; 

    const cleanFirstName = cleanText(user.first_name || '');
    const cleanLastName = cleanText(user.last_name || '');
    const fullName = `${cleanFirstName} ${cleanLastName}`.trim();
    const username = user.username ? `@${user.username}` : '@Vinszvvip';
    
    // Setting Waktu WIB Lengkap (Ada Hari, Tanggal, Bulan, Tahun)
    const now = new Date();
    const options = { 
      timeZone: 'Asia/Jakarta', 
      weekday: 'long', // Menampilkan Nama Hari
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    };
    const waktuWIB = now.toLocaleString('id-ID', options);
    
    const startInfo = `
<blockquote>🚀 𝗨𝗦𝗘𝗥 𝗝𝗢𝗜𝗡 𝗕𝗢𝗧
➥ 👤 𝗡𝗮𝗺𝗲: <b>${fullName}</b>
➥ 🆔 𝗨𝘀𝗲𝗿𝗜𝗗: <code>${user.id}</code>
➥ 👤 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲: ${username}</blockquote>
<blockquote>📅 𝗪𝗮𝗸𝘁𝘂 𝗝𝗼𝗶𝗻:
<i>${waktuWIB} WIB</i></blockquote>
🍂 𝗪𝗲𝗹𝗰𝗼𝗺𝗲 𝗧𝗼 𝗕𝗼𝘁 <b>${config.botName || "Bot"}</b>!`;

    await bot.telegram.sendMessage(ID_CHANNEL_LOG, startInfo, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: "Cek Profile 🔍", url: `tg://user?id=${user.id}` }]
        ]
      }
    });

    console.log(`[SUCCESS] Log User Join dikirim ke channel: ${ID_CHANNEL_LOG}`);
  } catch (error) {
    console.error("[ERROR] Gagal mengirim info start:", error.message);
  }
}


function cleanText(text) {
  if (!text) return '';
  return String(text)
    .replace(/\_/g, '\\_')
    .replace(/\*/g, '\\*')
    .replace(/\[/g, '\\[')
    .replace(/\]/g, '\\]')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)')
    .replace(/\~/g, '\\~')
    .replace(/\`/g, '\\`')
    .replace(/\>/g, '\\>')
    .replace(/\#/g, '\\#')
    .replace(/\+/g, '\\+')
    .replace(/\-/g, '\\-')
    .replace(/\=/g, '\\=')
    .replace(/\|/g, '\\|')
    .replace(/\{/g, '\\{')
    .replace(/\}/g, '\\}')
    .replace(/\./g, '\\.')
    .replace(/\!/g, '\\!')
    .trim();
}

async function sendTestimoniKeChannel(userName, userId, productName, amount, panelUser = null) {
  try {
    const TESTIMONI_CHANNEL = config.testimoniChannel;
    if (!TESTIMONI_CHANNEL) return;

    // 1. Setting Waktu + Hari (WIB)
    const now = new Date();
    const daftarHari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    const hari = daftarHari[now.getDay()];
    
    const waktuWIB = now.toLocaleString('id-ID', { 
      timeZone: 'Asia/Jakarta', 
      hour: '2-digit', 
      minute: '2-digit', 
      hour12: false 
    });
    
    const tanggal = now.toLocaleDateString('id-ID', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric' 
    });

    // 2. GENERATE ID TRANSAKSI UNIQUE
    const uniqueSuffix = Date.now().toString().slice(-4); 
    const randomStr = Math.random().toString(36).toUpperCase().substring(2, 6);
    const trxId = `VINSZVIP-${uniqueSuffix}${randomStr}`;

    // 3. Sensor ID & Cek Username
    const maskedId = userId.toString().slice(0, 4) + "xxxx";
    // Jika userName dari bot kosong, tampilkan 'User'
    const finalUserName = userName ? (userName.startsWith('@') ? userName : `${userName}`) : 'Pelanggan';
    
    // Baris info panel (Hanya muncul jika beli panel)
    const panelInfo = panelUser ? `➥👤 𝚞𝚜𝚎𝚛 𝚙𝚊𝚗𝚎𝚕 : <code>${panelUser}</code>\n` : "";

    const testimoniText = `
<blockquote>🛒 𝙩𝙧𝙖𝙣𝙨𝙖𝙠𝙨𝙞 𝙨𝙪𝙘𝙘𝙚𝙨
➥👤 𝚞𝚜𝚎𝚛 : ${finalUserName}
➥🆔 𝚞𝚜𝚎𝚛𝚒𝚍 : <code>xxxxx</code>
➥🧾 𝚒𝚍 𝚝𝚛𝚊𝚗𝚜𝚊𝚔𝚜𝚒 : <code>${trxId}</code></blockquote>
<blockquote>🎀 𝙙𝙚𝙩𝙖𝙞𝙡 𝙥𝙧𝙤𝙙𝙪𝙠
➥🛒 𝚙𝚛𝚘𝚍𝚞𝚔 : ${productName}
${panelInfo}➥💰 𝚑𝚊𝚛𝚐𝚊 : ${toRupiah(amount)}
➥⏰ 𝚠𝚊𝚔𝚝𝚞 : ${hari}, ${tanggal} | ${waktuWIB} WIB</blockquote>
<b>𝙞𝙣𝙜𝙞𝙣 𝙗𝙪𝙮 𝙘𝙡𝙞𝙘𝙠 𝙝𝙚𝙧𝙚?👇:</b>
@autoordervinsz_bot`;

    await bot.telegram.sendMessage(TESTIMONI_CHANNEL, testimoniText, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: "🛒 Beli Sekarang", url: `http://t.me/autoordervinsz_bot` }]
        ]
      }
    });
    
    console.log(`[SUCCESS] Testimoni Terkirim | ID: ${trxId}`);
  } catch (error) {
    console.error("[ERROR] Gagal mengirim testimoni:", error.message);
  }
}

function readManualPayments() {
  if (!fs.existsSync(MANUAL_PAYMENTS_DB)) {
    fs.writeFileSync(MANUAL_PAYMENTS_DB, JSON.stringify([]));
  }
  return JSON.parse(fs.readFileSync(MANUAL_PAYMENTS_DB));
}

function saveManualPayments(data) {
  fs.writeFileSync(MANUAL_PAYMENTS_DB, JSON.stringify(data, null, 2));
}

function getBotStats() {
  try {
    const users = loadUsers();
    const totalUsers = users.length;

    const uptime = Date.now() - botStartTime;
    const days = Math.floor(uptime / (1000 * 60 * 60 * 24));
    const hours = Math.floor((uptime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));

    return {
      totalUsers,
      runtime: `${days}d ${hours}h ${minutes}m`,
      botName: config.botName || "BOT TELEGRAM",
      ownerName: config.ownerName || "Owner",
      backupCount: "Auto" 
    };
  } catch (e) {
    return {
      totalUsers: "Error",
      runtime: "Unknown",
      botName: config.botName || "BOT TELEGRAM",
      ownerName: config.ownerName || "Owner",
      backupCount: "-"
    };
  }
}

function formatUserCard(ctx, msg) {
  const username = ctx.from.username ? `@${ctx.from.username}` : '-';
  return `<b>📩 PESAN DARI USER</b>\n<b>Username :</b> ${username}\n<b>ID User  :</b> ${ctx.from.id}\n\n<b>Pesan:</b>\n${msg}`;
}

bot.on("document", async (ctx, next) => {
  const userId = ctx.from.id;
  const state = userState[userId];

  if (state?.step === "WAITING_SCRIPT_FILE" && userId === config.ownerId) {
    const doc = ctx.message.document;

    if (!doc.file_name.endsWith(".zip"))
      return safeReply(ctx, "<blockquote>❌ File harus format .zip!</blockquote>", { parse_mode: "HTML" });

    userState[userId] = {
      step: "WAITING_SCRIPT_DETAIL",
      file_id: doc.file_id,
      temp_fileName: doc.file_name.replace(/\s/g, "_"),
    };

    return safeReply(ctx, `<blockquote>✅ <b>File diterima!</b>\n<b>Kirim detail:</b>\nNama | Harga | Deskripsi</blockquote>`, { parse_mode: "HTML" });
  }

  return next();
});

bot.command("pesan", async (ctx) => {
  const raw = ctx.message.text || "";
  const msg = raw.replace(/^\/pesan(@\w+)?\s*/i, "").trim();

  if (!msg) {
    liveChatState[ctx.from.id] = { step: "WAITING_MESSAGE" };
    return safeReply(ctx, "<blockquote>📝 <b>Silakan ketik pesan yang ingin dikirim ke owner.</b>\nKetik /batal untuk membatalkan.</blockquote>", { parse_mode: "HTML" });
  }

  return sendToOwner(ctx, msg);
});

bot.command("batal", (ctx) => {
  if (liveChatState[ctx.from.id]?.step === "WAITING_MESSAGE") {
    delete liveChatState[ctx.from.id];
    return safeReply(ctx, "❌ Pengiriman pesan dibatalkan.");
  }
  if (ownerReplyState[ctx.from.id]) {
    delete ownerReplyState[ctx.from.id];
    return safeReply(ctx, "❌ Mode balas owner dibatalkan.");
  }
  if (userState[ctx.from.id]?.step === "WAITING_BROADCAST" && ctx.from.id === config.ownerId) {
    delete userState[ctx.from.id];
    return safeReply(ctx, "❌ Broadcast dibatalkan.");
  }
  return; 
});

bot.on("text", async (ctx, next) => {
  try {
    const st = liveChatState[ctx.from.id];
    if (st && st.step === "WAITING_MESSAGE") {
      const text = ctx.message.text;
      delete liveChatState[ctx.from.id];
      return await sendToOwner(ctx, text);
    }
  } catch (e) {}
  return next();
});

async function sendToOwner(ctx, messageText) {
  try {
    const owner = config.ownerId;
    const layout = formatUserCard(ctx, messageText);
    await bot.telegram.sendMessage(owner, layout, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "💬 Balas Pesan", callback_data: `reply_${ctx.from.id}` }]
        ]
      }
    });
    await safeReply(ctx, "<blockquote>✅ <b>Pesan berhasil dikirim ke owner.</b></blockquote>", { parse_mode: "HTML" });
  } catch (err) {
    return safeReply(ctx, "❌ Gagal mengirim pesan ke owner.");
  }
}

bot.action(/reply_(\d+)/, async (ctx) => {
  try {
    if (String(ctx.from.id) !== String(config.ownerId)) {
      await ctx.answerCbQuery("❌ Hanya owner yang boleh membalas.", { show_alert: true });
      return;
    }
    const targetId = ctx.match[1];
    ownerReplyState[ctx.from.id] = { target: targetId, step: "WAITING_REPLY" };
    await ctx.answerCbQuery();
    await safeReply(ctx, "<blockquote>✉️ <b>Silakan kirim balasan Anda sekarang</b> (text / foto / voice / file).\nKetik /batal untuk batalkan.</blockquote>", { parse_mode: "HTML" });
  } catch (e) {}
});

async function forwardReplyToUser(ownerCtx, targetUserId, messageType, payload) {
  try {
    if (messageType === "text") {
      await bot.telegram.sendMessage(targetUserId, `<blockquote>💬 <b>Balasan dari Owner:</b>\n\n${payload}</blockquote>`, { parse_mode: "HTML" });
      await ownerCtx.reply("✅ Balasan terkirim sebagai teks.");
      return;
    }
  } catch (e) {
    await ownerCtx.reply("❌ Gagal mengirim balasan ke user.");
  }
}

bot.on("text", async (ctx, next) => {
  try {
    const st = ownerReplyState[ctx.from.id];
    if (st && st.step === "WAITING_REPLY") {
      const target = st.target;
      const text = ctx.message.text;
      delete ownerReplyState[ctx.from.id];
      await forwardReplyToUser(ctx, target, "text", text);
      return;
    }
  } catch (e) {}
  return next();
});

function getFileExtension(name) {
    const ext = name.split(".").pop().toLowerCase();
    if (["js"].includes(ext)) return "javascript";
    if (["py"].includes(ext)) return "python";
    if (["html","htm"].includes(ext)) return "html";
    if (["css"].includes(ext)) return "css";
    if (["json"].includes(ext)) return "json";
    if (["zip","rar","7z","tar","gz"].includes(ext)) return "archive";
    return "text";
}

async function downloadFile(fileId) {
    try {
        const fileLink = await bot.telegram.getFileLink(fileId);
        const res = await axios.get(fileLink, { responseType: "arraybuffer" });
        return res.data;
    } catch (err) {
        throw new Error("Gagal download file: " + err.message);
    }
}

function getFileContent(buffer) {
    try {
        return Buffer.from(buffer).toString("utf8");
    } catch (err) {
        throw new Error("Gagal membaca file: " + err.message);
    }
}

async function analyzeErrorWithGemini(codeContent, fileName) {
    try {
        if (getFileExtension(fileName) === "archive") {
            return "❌ <b>File adalah arsip (zip/rar), bukan file kode.</b>\nSilakan ekstrak dulu dan kirim file kode individual (js, py, html, css, json).";
        }
        
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent?key=${config.GEMINI_API_KEY}`,
            {
                contents: [{
                    parts: [{
                        text: `Deteksi error pada file bernama ${fileName}. Berikan hasilnya dalam format:

\`\`\`${getFileExtension(fileName)}
(kode atau analisis singkat di sini)
\`\`\`

JANGAN beri penjelasan panjang. Singkat & jelas saja.

Isi file:
${codeContent}
`
                    }]
                }]
            }
        );
        return res.data.candidates[0].content.parts[0].text;
    } catch (err) {
        throw new Error("Gemini error: " + err.message);
    }
}

async function fixErrorWithGemini(codeContent, fileName) {
    try {
        if (getFileExtension(fileName) === "archive") {
            throw new Error("File adalah arsip (zip/rar), bukan file kode. Silakan ekstrak dulu.");
        }
        
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent?key=${config.GEMINI_API_KEY}`,
            {
                contents: [{
                    parts: [{
                        text: `Perbaiki error dalam file ${fileName} dan kirimkan hanya kode final:\n\n${codeContent}`
                    }]
                }]
            }
        );
        return res.data.candidates[0].content.parts[0].text;
    } catch (err) {
        throw new Error("Gemini error: " + err.message);
    }
}

const premiumUsers = new Set([config.ownerId]);
let userLimits = new Map();

function updateUserLimit(userId) {
    if (premiumUsers.has(userId)) return 999;
    const now = userLimits.get(userId) || config.USER_LIMIT;
    const sisa = now - 1;
    userLimits.set(userId, sisa);
    return sisa;
}

function getUserLimit(userId) {
    return premiumUsers.has(userId) ? "Unlimited" : (userLimits.get(userId) || config.USER_LIMIT);
}

function loadUsers() {
  if (!fs.existsSync(USERS_DB)) {
    fs.writeFileSync(USERS_DB, JSON.stringify([]));
  }
  return JSON.parse(fs.readFileSync(USERS_DB));
}

function saveUsers(list) {
  fs.writeFileSync(USERS_DB, JSON.stringify(list, null, 2));
}

function checkAndAddUser(user) {
  const users = loadUsers();
  const isNewUser = !users.includes(user.id);
  
  if (isNewUser) {
    users.push(user.id);
    saveUsers(users);
    sendStartInfoToChannel(user);
    return true;
  }
  return false;
}

bot.on("message", (ctx, next) => {
  try {
    checkAndAddUser(ctx.from);
  } catch (e) {
    console.error("[ERROR] Error adding user:", e);
  }
  return next();
});

function readDb() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({
      isPanelOpen: true,
      scripts: [],
      apps: [],
      paymentMethod: config.payment?.method || 'orkut'
    }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDb(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function getActivePaymentMethod() {
  const db = readDb();
  return (db && db.paymentMethod) ? db.paymentMethod : (config.payment?.method || 'orkut');
}
function setActivePaymentMethod(method) {
  const db = readDb();
  db.paymentMethod = method;
  saveDb(db);
}

async function createPanelAccount(username, ram, disk, cpu) {
  try {
    const headers = {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": `Bearer ${config.panel.apikey}`
    };
    const password = username + "001";
    const email = `${username.toLowerCase()}@gmail.com`;

    const userRes = await axios.post(`${config.panel.domain}/api/application/users`, {
      email, username: username.toLowerCase(), first_name: username, last_name: "User", language: "en", password
    }, { headers });

    const user = userRes.data.attributes;

    await axios.post(`${config.panel.domain}/api/application/servers`, {
      name: `${username} Server`,
      user: user.id,
      egg: config.panel.eggId,
      docker_image: config.panel.image,
      startup: config.panel.startup,
      environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
      limits: { memory: ram, swap: 0, disk: disk, io: 500, cpu: cpu },
      feature_limits: { databases: 1, backups: 1, allocations: 1 },
      deploy: { locations: [config.panel.locationId], dedicated_ip: false, port_range: [] }
    }, { headers });

    return { success: true, data: { username: user.username, password, login: config.panel.domain } };
  } catch (error) {
    return { success: false, msg: error.response?.data?.errors?.[0]?.detail || error.message };
  }
}

bot.start(async (ctx) => {
  // 1. Ambil data dari file JSON untuk statistik real-time
  const manualPayments = JSON.parse(fs.readFileSync('./manual_payments.json'));
  const usersData = JSON.parse(fs.readFileSync('./users.json'));
  
  // 2. Hitung statistik dari script
  const stats = {
    runtime: getBotStats().runtime, // Mengambil runtime dari fungsi existing
    totalUsers: usersData.length,
    totalTransactions: manualPayments.length,
    totalPendapatan: manualPayments.reduce((sum, trx) => sum + (trx.nominal || 0), 0),
    backupCount: getBotStats().backupCount || 0
  };

  const isNewUser = checkAndAddUser(ctx.from);
  const cleanFirstName = cleanText(ctx.from.first_name || 'Pengguna');

  // 3. Gabungkan ke dalam welcomeText
  const welcomeText = `<blockquote>🚀 𝐀𝐔𝐓𝐎 𝐎𝐑𝐃𝐄𝐑
ʙᴏᴛ ʟᴀʏᴀɴᴀɴ ᴏᴛᴏᴍᴀᴛɪꜱ ʏᴀɴɢ ʙᴇʀᴛᴜɢᴀꜱ
ᴍᴇᴍᴘᴇʀᴄᴇᴘᴀᴛ ᴛʀᴀɴꜱᴀᴋꜱɪ ᴅᴇɴɢᴀɴ layanan</blockquote>
<blockquote>⚙️SISTEM FULL OTOMATIS
➥Auto create panel
➥Auto proses pembayaran
➥Auto kirim data akun
➥Online 24/7 nonstop</blockquote>
<blockquote>📊 𝐒𝐓𝐀𝐓𝐈𝐒𝐓𝐈𝐊
🪧 𝙧𝙪𝙣𝙩𝙞𝙢𝙚 𝙗𝙤𝙩 : ${stats.runtime}
👥 𝚝𝚘𝚝𝚊𝚕 𝚞𝚜𝚎𝚛𝚜 𝚋𝚘𝚝 : ${stats.totalUsers}
💰 𝚝𝚘𝚝𝚊𝚕 𝚙𝚎𝚗𝚍𝚊𝚙𝚊𝚝𝚊𝚗 : Rp ${stats.totalPendapatan.toLocaleString('id-ID')}
🛒 𝚝𝚘𝚝𝚊𝚕 𝚝𝚛𝚊𝚗𝚜𝚊𝚔𝚜𝚒 : ${stats.totalTransactions}</blockquote>
<blockquote>auto order VINSZ★</blockquote>`;
const menuKeyboard = {
  inline_keyboard: [
    [
      { text: "☇ 🛍️all produk", callback_data: "shop_menu" },
      { text: " ☇ 🛠️mood tools", callback_data: "menu_tools" }
    ],
    [
      { text: "👑 owners", callback_data: "menu_owner_contact" },
      { text: "📣 channel resmi", callback_data: "menu_developer" }
    ]
  ]
};

  if (config.startPhoto) {
    try {
      await ctx.replyWithPhoto(config.startPhoto, {
        caption: welcomeText,
        parse_mode: "HTML",
        reply_markup: menuKeyboard
      });
    } catch (e) {
      await safeReply(ctx, welcomeText, {
        parse_mode: "HTML",
        reply_markup: menuKeyboard
      });
    }
  } else {
    await safeReply(ctx, welcomeText, {
      parse_mode: "HTML",
      reply_markup: menuKeyboard
    });
  }

  if (config.startAudio && config.startAudio.trim() !== "") {
    try {
      await ctx.replyWithAudio(config.startAudio, {
        caption: config.startAudioCaption || "",
        parse_mode: "HTML"
      });
    } catch (audioError) {
      console.error("[ERROR] Failed to send start audio:", audioError.message);
    }
  }

  if (ctx.from.id === config.ownerId) {
    await safeReply(ctx, `<blockquote><b>👑 Selamat Datang Owner!</b></blockquote>`, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "🔧 Menu Owner", callback_data: "menu_owner" }]]
      }
    });
  }
});

bot.action("menu_scripts", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'menu_scripts')) return;
  
  const db = readDb();
  if ((db.scripts || []).length === 0) {
    await editMenuMessage(ctx, "⚠️ <b>Belum ada produk script yang tersedia.</b>", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 Kembali", callback_data: "back_home" }]
        ]
      }
    });
    return;
  }
  
  const buttons = db.scripts.map((item, index) => {
    return [{ text: `${item.nama} - ${toRupiah(item.harga)}`, callback_data: `buy_sc_${index}` }];
  });
  
  buttons.push([{ text: "🔙 Kembali", callback_data: "back_home" }]);
  
  await editMenuMessage(ctx, "<b>📂 𝗣𝗶𝗹𝗶𝗵 𝗦𝗰𝗿𝗶𝗽𝘁 𝗬𝗮𝗻𝗴 𝗜𝗻𝗴𝗶𝗻 𝗞𝗮𝗺𝘂 𝗕𝗲𝗹𝗶:</b>", {
    reply_markup: { inline_keyboard: buttons }
  });
});

bot.action("menu_apps", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'menu_apps')) return;
  
  const db = readDb();
  if ((db.apps || []).length === 0) {
    await editMenuMessage(ctx, "⚠️ <b>Belum ada aplikasi tersedia.</b>", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 Kembali", callback_data: "back_home" }]
        ]
      }
    });
    return;
  }
  
  const buttons = db.apps.map((app, i) => {
    const stock = (app.accounts || []).length;
    return [{ text: `${app.nama} (${stock} stok) - ${toRupiah(app.harga)}`, callback_data: `buy_app_${i}` }];
  });
  
  buttons.push([{ text: "🔙 Kembali", callback_data: "back_home" }]);
  
  await editMenuMessage(ctx, "<b>📱 𝗗𝗮𝗳𝘁𝗮𝗿 SC CPANEL:</b>", {
    reply_markup: { inline_keyboard: buttons }
  });
});

bot.action("メニュー _panel", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'menu_panel')) return;
  
  const db = readDb();
  if (!db.isPanelOpen) {
    await editMenuMessage(ctx, "<b>🔒 Maaf, Stok Panel Sedang Kosong/Maintenance.</b>\nSilahkan coba lagi nanti.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 Kembali", callback_data: "back_home" }]
        ]
      }
    });
    return;
  }

  userState[ctx.from.id] = { step: "WAITING_USERNAME_PANEL" };

  await editMenuMessage(ctx,
    "<b>🍂 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗞𝗶𝗿𝗶𝗺 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 𝗨𝗻𝘁𝘂𝗸 𝗣𝗮𝗻𝗲𝗹 𝗞𝗮𝗺𝘂 𝗠𝗶𝗻𝗶𝗺𝗮𝗹 𝟱-𝟴 𝗛𝘂𝗿𝘂𝗳.</b>\n\n<i>Kirim username sekarang...</i>",
    {
      reply_markup: {
        inline_keyboard: [
          [{ text: "❌ Batalkan", callback_data: "back_home" }]
        ]
      }
    }
  );

  setTimeout(() => {
    const st = userState[ctx.from.id];
    if (st && st.step === "WAITING_USERNAME_PANEL") {
      delete userState[ctx.from.id];
      safeReply(ctx, "<blockquote>❌ <b>Waktu habis!</b> Silahkan mulai ulang pembelian panel.</blockquote>", { parse_mode: "HTML" });
    }
  }, 60000);
});

bot.action("shop_menu", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'shop_menu')) return;
  
await editMenuMessage(ctx, 
    `<blockquote><b>🛍️ 𝗦𝗛𝗢𝗣 𝗠𝗘𝗡𝗨</b>
━━━━━━━━━━━━━━━━━━━━━━
Pilih kategori produk yang ingin dibeli:</blockquote>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "📱 ☇ 𝗡𝗼𝗸𝗼𝘀", callback_data: "choose_service" },
            { text: "📁 ☇ 𝗦𝗰𝗿𝗶𝗽𝘁𝘀", callback_data: "menu_scripts" }
          ],
          [
            { text: "📱 ☇ SC CPANEL", callback_data: "menu_apps" },
            { text: "📡 ☇ 𝗣𝗮𝗻𝗲𝗹", callback_data: "menu_panel" }
          ],
          [
            { text: "🖥 ☇ 𝗩𝗽𝘀", callback_data: "buyvps_start" },
            { text: "🔙 Kembali", callback_data: "back_home" }
          ]
        ]
      }
    }
  );
});


bot.action("menu_tools", async (ctx) => {
  await editMenuMessage(ctx, 
    `<blockquote><b>╭━━━━✧「 𝗧𝗢𝗢𝗟𝗦 𝗠𝗘𝗡𝗨 」✧━━━━❍</b>
<b>┃ 🎬 𝗬𝗼𝘂𝘁𝘂𝗯𝗲</b>
<b>┃ ├⌑</b> /ytsearch <i>(Searching YouTube)</i>
<b>┃ └⌑</b> /ytmp3 <i>(Audio)</i>
<b>┃</b>
<b>┃ 🎥 𝗧𝗶𝗸𝗧𝗼𝗸</b>
<b>┃ └⌑</b> /tiktokmp4 <i>(Video)</i>
<b>┃</b>
<b>┃ 📝 𝗖𝗼𝗱𝗲 𝗛𝗲𝗹𝗽</b>
<b>┃ ├⌑</b> /checkerror
<b>┃ └⌑</b> /fixerror
<b>┃</b>
<b>┃ 🛠️ 𝗧𝗼𝗼𝗹𝘀 𝗕𝗮𝗿𝘂</b>
<b>┃ ├⌑</b> /makeqr
<b>┃ ├⌑</b> /ssweb
<b>┃ ├⌑</b> /shorten
<b>┃ ├⌑</b> /qc <i>(Quote Creator)</i>
<b>┃ ├⌑</b> /brat <i>(Brat Sticker)</i>
<b>┃ └⌑</b> /tourl <i>(Upload to URL)</i>
<b>╰━━━━━━━━━━━━━━━━━━━━━━━━❍</b></blockquote>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 Kembali", callback_data: "back_home" }]
        ]
      }
    }
  );
});

bot.action('menu_developer', async (ctx) => {
  const devKeyboard = {
    inline_keyboard: [
      [{ text: "chanell resmi↗️", url: "https://t.me/vinszviip" }],
      [{ text: "ownersss ↗️", url: "http://t.me/Vinszvvip" }],
      [{ text: "⬅️ Kembali", callback_data: "back_home" }]
    ]
  };

  try {
    await ctx.answerCbQuery().catch(() => {});
    // Karena menu developer biasanya gak pake foto, kita edit caption fotonya saja
    await ctx.editMessageCaption("<blockquote>channel resmi kami</blockquote>", {
      parse_mode: 'HTML',
      reply_markup: devKeyboard
    }).catch(async () => {
      // Kalau ternyata gak ada foto, dia lari ke sini
      await ctx.editMessageText("<blockquote>channel resmi kami</blockquote>", {
        parse_mode: 'HTML',
        reply_markup: devKeyboard
      });
    });
  } catch (e) {
    console.log(e);
  }
});


bot.action("menu_owner_contact", async (ctx) => {
  await editMenuMessage(ctx,
    `<blockquote><b>📞「 𝗖𝗢𝗡𝗧𝗔𝗖𝗧 𝗢𝗪𝗡𝗘𝗥 𝗕𝗢𝗧 」</b>\n` +
    `<b>━━━━━━━━━━━━━━━━━━━━━━❍</b>\n` +
    `<b>🍂 𝗡𝗮𝗺𝗲 :</b> ${config.ownerName || "𝗔𝗱𝗺𝗶𝗻"}\n` +
    `<b>📲 𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 :</b> ${config.ownerWa}\n` +
    `<b>✈️ 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 :</b> ${config.ownerUser}\n` +
    `<b>━━━━━━━━━━━━━━━━━━━━━━❍</b>\n` +
    `📩 𝗞𝗮𝗺𝘂 𝗟𝗶𝗺𝗶𝘁? 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗞𝗹𝗶𝗸 𝗖𝗼𝗺𝗺𝗮𝗻𝗱 𝗗𝗶𝘀𝗮𝗺𝗽𝗶𝗻𝗴 : /pesan</blockquote>\n`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "💬 Kirim Pesan ke Owner", callback_data: "send_message_owner" }],
          [{ text: "🔙 Kembali", callback_data: "back_home" }]
        ]
      }
    }
  );
});


bot.action("send_message_owner", async (ctx) => {
  liveChatState[ctx.from.id] = { step: "WAITING_MESSAGE" };
  await editMenuMessage(ctx, 
    "<blockquote>📝 <b>Silakan ketik pesan yang ingin dikirim ke owner.</b>\n\n<i>Ketik /batal untuk membatalkan</i></blockquote>",
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "❌ Batalkan", callback_data: "back_home" }]
        ]
      }
    }
  );
});

bot.action("back_home", async (ctx) => {
  try {
    await ctx.answerCbQuery().catch(() => {});
    
    // Ambil stats dengan pengaman
    const stats = typeof getBotStats === 'function' ? getBotStats() : {};
    const pendapatan = (stats.totalPendapatan || 0).toLocaleString('id-ID');
    const users = stats.totalUsers || 0;
    const runtime = stats.runtime || "0d 0h 0m";
    const transaksi = stats.totalTransactions || 0;

    const welcomeText = `<blockquote>🚀 𝐀𝐔𝐓𝐎 𝐎𝐑𝐃𝐄𝐑
ʙᴏᴛ ʟᴀʏᴀɴᴀɴ ᴏᴛᴏᴍᴀᴛɪꜱ ʏᴀɴɢ ʙᴇʀᴛᴜɢᴀꜱ
ᴍᴇᴍᴘᴇʀᴄᴇᴘᴀᴛ ᴛʀᴀɴꜱᴀᴋꜱɪ ᴅᴇɴɢᴀɴ layanan</blockquote>
<blockquote>⚙️SISTEM FULL OTOMATIS
➥Auto create panel
➥Auto proses pembayaran
➥Auto kirim data akun
➥Online 24/7 nonstop</blockquote>
<blockquote>auto order VINSZ★</blockquote>`;

    const menuKeyboard = {
      inline_keyboard: [
        [{ text: "☇ 🛍️all produk", callback_data: "shop_menu" }, { text: " ☇ 🛠️mood tools", callback_data: "menu_tools" }],
        [{ text: "👑 owners", callback_data: "menu_owner_contact" }, { text: "👨‍💻 channel resmi", callback_data: "menu_developer" }]
      ]
    };

    // LOGIKA UNTUK MUNCULIN FOTO LAGI
    if (config.startPhoto) {
      await ctx.editMessageMedia({
        type: 'photo',
        media: config.startPhoto,
        caption: welcomeText,
        parse_mode: 'HTML'
      }, {
        reply_markup: menuKeyboard
      }).catch(async () => {
        // Fallback kalau edit media gagal, coba edit caption saja
        await ctx.editMessageCaption(welcomeText, {
          parse_mode: 'HTML',
          reply_markup: menuKeyboard
        }).catch(() => {});
      });
    } else {
      await ctx.editMessageText(welcomeText, {
        parse_mode: 'HTML',
        reply_markup: menuKeyboard
      }).catch(() => {});
    }

  } catch (err) {
    console.error("Gagal Backhome Total:", err.message);
  }
});

function showOwnerMenu(ctx) {
  if (ctx.from.id !== config.ownerId) 
    return safeReply(ctx, "<blockquote>🚫 𝗞𝗮𝗺𝘂 𝗕𝘂𝗸𝗮𝗻 𝗢𝘄𝗻𝗲𝗿 𝗕𝗼𝘁!</blockquote>", { parse_mode: "HTML" });

  safeReply(ctx, `<blockquote><b>👑 𝗠𝗘𝗡𝗨 𝗢𝗪𝗡𝗘𝗥</b>\n<b>𝖲𝗂𝗅𝖺𝗁𝗄𝖺𝗇 𝖳𝖾𝗄𝖺𝗇 𝖡𝗎𝗍𝗍𝗈𝗇 𝖣𝗂𝖻𝖺𝗐𝖺𝗁:</b></blockquote>`,
    {
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        [ Markup.button.callback("🟢 Panel Online / Offline", "owner_panel") ],
        [ Markup.button.callback("📢 Broadcast", "owner_broadcast") ],
        [
          Markup.button.callback("➕ Add Script", "add_script"),
          Markup.button.callback("🗑 Delete Script", "del_script")
        ],
        [
          Markup.button.callback("📱 Add App Premium", "add_app"),
          Markup.button.callback("🗑 Delete App", "del_app")
        ],
        [
          Markup.button.callback("➕ Add Account", "owner_add_account"),
          Markup.button.callback("🗑 Delete Account", "owner_del_account")
        ],
        [ Markup.button.callback("🖥️ List VPS Orders", "list_vps_orders") ],
        [ Markup.button.callback("📃 List App Premium", "list_apps") ],
        [ Markup.button.callback("💳 Ganti Payment", "change_payment") ],
        [ Markup.button.callback("🧾 Manual Payments", "manual_payments_menu") ],
        [ Markup.button.callback("💰 Withdraw RumahOTP", "wd_rumahotp_start") ],
        [ Markup.button.callback("💸 Withdraw Atlantic", "menu_wd_info") ],
        [ Markup.button.callback("💾 Backup Database", "backup_database") ],
        [ Markup.button.callback("🔙 Kembali", "back_home") ]
      ])
    }
  );
}

bot.action("menu_owner", (ctx) => {
  ctx.answerCbQuery().catch(()=>{});
  showOwnerMenu(ctx);
});

bot.action("list_vps_orders", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner yang boleh melihat order VPS!", { show_alert: true });
  }
  
  const vpsPath = "./database/data_vps.json";
  
  if (!fs.existsSync(vpsPath)) {
    return safeReply(ctx, "<blockquote>📭 Belum ada data VPS yang terjual.</blockquote>", { 
      parse_mode: "HTML" 
    });
  }
  
  try {
    const vpsDB = JSON.parse(fs.readFileSync(vpsPath));
    
    if (!Array.isArray(vpsDB) || vpsDB.length === 0) {
      return safeReply(ctx, "<blockquote>📭 Belum ada data VPS yang terjual.</blockquote>", { 
        parse_mode: "HTML" 
      });
    }
    
    let message = "<b>📋 DAFTAR ORDER VPS</b>\n\n";
    
    vpsDB.forEach((vps, i) => {
      message += `<b>${i + 1}. ${vps.hostname}</b>\n`;
      message += `<code>   User:</code> ${vps.username} (${vps.userId})\n`;
      message += `<code>   IP:</code> ${vps.ip}\n`;
      message += `<code>   Region:</code> ${vps.region}\n`;
      message += `<code>   Paket:</code> ${vps.paket}\n`;
      message += `<code>   Harga:</code> ${toRupiah(vps.harga)}\n`;
      message += `<code>   Tanggal:</code> ${vps.created}\n\n`;
    });
    
    await safeReply(ctx, message, {
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("🔙 Kembali", "menu_owner")]
      ])
    });
    
  } catch (error) {
    console.error("Error reading VPS data:", error);
    safeReply(ctx, "<blockquote>❌ Gagal membaca data VPS.</blockquote>", { 
      parse_mode: "HTML" 
    });
  }
});

bot.action("backup_database", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner yang boleh backup!", { show_alert: true });
  }
  
  await ctx.answerCbQuery("⏳ Memproses Full Backup...", { show_alert: false });
  await safeReply(ctx, "<blockquote>📦 <b>Sedang mempacking seluruh Source Code & Database...</b>\n<i>Mohon tunggu, proses tergantung ukuran file.</i></blockquote>", { parse_mode: "HTML" });
  
  createAndSendFullBackup(ctx, false);
});


bot.action("manual_payments_menu", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  ctx.answerCbQuery().catch(()=>{});
  
  const payments = readManualPayments();
  const pendingCount = payments.filter(p => p.status === "pending").length;
  
  safeReply(ctx, `<blockquote><b>🧾 𝗠𝗲𝗻𝘂 𝗣𝗮𝘆𝗺𝗲𝗻𝘁 𝗠𝗮𝗻𝘂𝗮𝗹</b>\n<b>𝖯𝖾𝗇𝖽𝗂𝗇𝗀:</b> ${pendingCount}</blockquote>`, {
    parse_mode: "HTML",
    ...Markup.inlineKeyboard([
      [ Markup.button.callback("📋 𝗟𝗶𝘀𝘁 𝗣𝗲𝗻𝗱𝗶𝗻𝗴", "list_pending_payments") ],
      [ Markup.button.callback("📜 𝗔𝗹𝗹 𝗣𝗮𝘆𝗺𝗲𝗻𝘁", "list_all_payments") ],
      [ Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "menu_owner") ]
    ])
  });
});

bot.action("list_pending_payments", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  
  const payments = readManualPayments();
  const pending = payments.filter(p => p.status === "pending");
  
  if (pending.length === 0) {
    safeReply(ctx, "✅ Tidak ada pembayaran pending.");
    return showOwnerMenu(ctx);
  }
  
  let message = "<b>📋 Pembayaran Pending</b>\n\n";
  pending.forEach((p, i) => {
    message += `<b>${i+1}. ${p.userName} (${p.userId})</b>\n`;
    message += `<code>   Item:</code> ${p.itemName}\n`;
    message += `<code>   Amount:</code> ${toRupiah(p.amount)}\n`;
    message += `<code>   Time:</code> ${new Date(p.timestamp).toLocaleString()}\n`;
    message += `   [Verify](tg://user?id=${p.userId})\n\n`;
  });
  
  safeReply(ctx, message, {
    parse_mode: "HTML",
    ...Markup.inlineKeyboard([
      [ Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "manual_payments_menu") ]
    ])
  });
});

bot.action("list_all_payments", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  
  const payments = readManualPayments();
  
  if (payments.length === 0) {
    safeReply(ctx, "📭 Belum ada riwayat pembayaran manual.");
    return showOwnerMenu(ctx);
  }
  
  let message = "<b>📜 Riwayat Semua Pembayaran Manual</b>\n\n";
  payments.forEach((p, i) => {
    const statusEmoji = p.status === "approved" ? "✅" : p.status === "rejected" ? "❌" : "⏳";
    message += `<b>${i+1}. ${statusEmoji} ${p.userName}</b>\n`;
    message += `<code>   Item:</code> ${p.itemName}\n`;
    message += `<code>   Amount:</code> ${toRupiah(p.amount)}\n`;
    message += `<code>   Status:</code> ${p.status}\n`;
    message += `<code>   Time:</code> ${new Date(p.timestamp).toLocaleString()}\n\n`;
  });
  
  safeReply(ctx, message, {
    parse_mode: "HTML",
    ...Markup.inlineKeyboard([
      [ Markup.button.callback("🔙 Kembali", "manual_payments_menu") ]
    ])
  });
});

bot.action("change_payment", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  ctx.answerCbQuery().catch(()=>{});
  const active = getActivePaymentMethod();
  safeReply(ctx, `<blockquote><b>🔧 Payment aktif saat ini:</b> <code>${active.toUpperCase()}</code>\n<b>Pilih payment baru:</b></blockquote>`, {
    parse_mode: "HTML",
    ...Markup.inlineKeyboard([
      [ Markup.button.callback("🌊 𝗔𝘁𝗹𝗮𝗻𝘁𝗶𝗰", "set_payment_atlantic") ],
      [ Markup.button.callback("🟣 𝗢𝗿𝗸𝘂𝘁 / 𝗢𝗿𝗱𝗲𝗿𝗞𝘂𝗼𝘁𝗮", "set_payment_orkut") ],
      [ Markup.button.callback("👨‍💼 𝗠𝗮𝗻𝘂𝗮𝗹 (𝗤𝗥𝗜𝗦 𝗙𝗼𝘁𝗼)", "set_payment_manual") ],
      [ Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "menu_owner") ]
    ])
  });
});

bot.action("set_payment_atlantic", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  setActivePaymentMethod("atlantic");
  safeReply(ctx, "<blockquote>✅ <b>Payment berhasil diganti ke ATLANTIC</b></blockquote>", { parse_mode: "HTML" });
  showOwnerMenu(ctx);
});

bot.action("set_payment_orkut", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  setActivePaymentMethod("orkut");
  safeReply(ctx, "<blockquote>✅ <b>Payment berhasil diganti ke ORKUT</b></blockquote>", { parse_mode: "HTML" });
  showOwnerMenu(ctx);
});

bot.action("set_payment_manual", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  setActivePaymentMethod("manual");
  safeReply(ctx, "<blockquote>✅ <b>Payment berhasil diganti ke MANUAL (QRIS FOTO)</b></blockquote>", { parse_mode: "HTML" });
  showOwnerMenu(ctx);
});

bot.action("owner_panel", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  const db = readDb();
  db.isPanelOpen = !db.isPanelOpen;
  saveDb(db);
  const status = db.isPanelOpen ? "🟢 ONLINE" : "🔴 OFFLINE";
  safeReply(ctx, `<blockquote><b>Status panel sekarang:</b> ${status}</blockquote>`, { parse_mode: "HTML" });
});

bot.action("owner_broadcast", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  ctx.answerCbQuery().catch(()=>{});
  userState[ctx.from.id] = { step: "WAITING_BROADCAST" };
  safeReply(ctx, "<blockquote>📢 <b>Silakan kirim pesan broadcast (teks atau foto).</b>\nKetik /batal untuk membatalkan.</blockquote>", {
    parse_mode: "HTML",
    ...Markup.inlineKeyboard([
      [Markup.button.callback("❌ Batalkan Broadcast", "cancel_broadcast")]
    ])
  });
});

bot.action("cancel_broadcast", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  if (userState[ctx.from.id]?.step === "WAITING_BROADCAST") {
    delete userState[ctx.from.id];
    safeReply(ctx, "❌ Broadcast dibatalkan.");
    showOwnerMenu(ctx);
  }
});

bot.action("buyvps_start", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_start')) return;
  
  await editMenuMessage(ctx,
`🛒 *KATALOG VPS DIGITALOCEAN*
━━━━━━━━━━━━━━━━━━━━━━
📦 *STOK TERSEDIA:* Ready untuk pemesanan!

⚙️ *Pilih tipe VPS sesuai kebutuhan Anda:*

🟢 *LOW VPS*
▪ Garansi: *7 Hari*
▪ Replace: *1x*
▪ harga mulai: *Rp5.000*
━━━━━━━━━━━━━━━━━━━━━━

🟡 *MEDIUM VPS*
▪ Garansi: *15 Hari*
▪ Replace: *2x*
▪ Harga mulai: *Rp15.000*
━━━━━━━━━━━━━━━━━━━━━━

🔴 *HIGH VPS*
▪ Garansi: *30 Hari*
▪ Replace: *7×*
▪ Harga mulai: *Rp30.000*
━━━━━━━━━━━━━━━━━━━━━━
✨ Silakan pilih kategori VPS:`,
    {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🟢 LOW", callback_data: "buyvps_pkg:low" }],
          [{ text: "🟡 MEDIUM", callback_data: "buyvps_pkg:medium" }],
          [{ text: "🔴 HIGH", callback_data: "buyvps_pkg:high" }],
          [{ text: "🔙 Kembali", callback_data: "shop_menu" }]
        ]
      }
    }
  );
});

bot.action(/buyvps_pkg:(low|medium|high)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_pkg')) return;
  
  const paket = ctx.match[1];
  const userId = ctx.from.id;
  
  const count = await getDropletCount();
  const sisaVPS = Math.max(0, 10 - count);

  if (sisaVPS <= 0) {
    return editMenuMessage(ctx,
`❌ *STOK VPS HABIS*

Mohon Maaf Sebesar-besarnya 🙏  
Stok VPS kami *sudah habis* 😞

Silahkan hubungi *ADMIN* untuk meminta restock VPS,  
atau coba beberapa menit lagi.`,
      {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🔙 Kembali", callback_data: "buyvps_start" }]
          ]
        }
      }
    );
  }

  if (!userState[userId]) userState[userId] = {};
  userState[userId].vpsData = { paket };

  let listRam = [];
  const dataHarga = config.hargaVPS?.[paket] || {};

  listRam = [
    { id: 1, label: "2GB 2 CPU | 60GB SSD | 3TB BW", plan: "2c2" },
    { id: 2, label: "4GB 2 CPU | 80GB SSD | 4TB BW", plan: "4c2" },
    { id: 3, label: "8GB 4 CPU | 160GB SSD | 5TB BW", plan: "8c4" },
    { id: 4, label: "16GB 4 CPU | 200GB SSD | 8TB BW", plan: "16c4" },
    { id: 5, label: "16GB 8 CPU | 320GB SSD | 6TB BW", plan: "16c8" }
  ];

  listRam = listRam.map(x => ({
    ...x,
    harga: dataHarga[x.plan] || 0
  }));

  let teks = `🖥 *PILIH SPESIFIKASI VPS*\n` +
             `──────────────────────────\n\n`;

  for (const item of listRam) {
    teks += `*${item.id}.* ${item.label}\n` +
            `└➤ *Rp ${item.harga.toLocaleString("id-ID")}*\n` +
            `──────────────────────────\n`;
  }

  teks += `\n✅ *STOK TERSEDIA : ${sisaVPS} VPS*`;

  const keyboard = listRam.map(v => [
    { 
      text: `${v.id}. ${v.label.split("|")[0].trim()} - Rp ${v.harga.toLocaleString("id-ID")}`, 
      callback_data: `buyvps_ram:${v.plan}` 
    }
  ]);

  keyboard.push([{ text: "🔙 Kembali", callback_data: "buyvps_start" }]);

  await editMenuMessage(ctx, teks, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: keyboard }
  });
});

bot.action(/buyvps_ram:(.+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_ram')) return;
  
  const plan = ctx.match[1];
  const userId = ctx.from.id;
  
  if (userState[userId]?.vpsData) {
    userState[userId].vpsData.plan = plan;
  }

  const osFamily = [
    { name: "Ubuntu", key: "ubuntu" },
    { name: "Debian", key: "debian" },
    { name: "CentOS Stream", key: "centos" },
    { name: "Fedora", key: "fedora" },
    { name: "AlmaLinux", key: "almalinux" },
    { name: "Rocky Linux", key: "rocky" },
  ];

  const keyboard = osFamily.map(os => [{
    text: os.name,
    callback_data: `buyvps_osfamily:${os.key}`
  }]);

  keyboard.push([
    { text: "🔙 Kembali", callback_data: `buyvps_pkg:${userState[userId]?.vpsData?.paket}` }
  ]);

  await editMenuMessage(ctx,
    `💾 *Spesifikasi Dipilih*: ${plan}\n\nPilih *OS Family*:`,
    {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard }
    }
  );
});

bot.action(/buyvps_osfamily:(.+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_osfamily')) return;
  
  const osKey = ctx.match[1];
  const userId = ctx.from.id;
  
  if (userState[userId]?.vpsData) {
    userState[userId].vpsData.osFamily = osKey;
  }

  const osVersions = {
    ubuntu: [
      { name: "Ubuntu 22.04", slug: "ubuntu-22-04-x64" },
      { name: "Ubuntu 24.04", slug: "ubuntu-24-04-x64" },
      { name: "Ubuntu 25.04", slug: "ubuntu-25-04-x64" },
    ],
    debian: [
      { name: "Debian 12", slug: "debian-12-x64" },
      { name: "Debian 13", slug: "debian-13-x64" },
    ],
    centos: [
      { name: "CentOS Stream 9", slug: "centos-stream-9-x64" },
    ],
    fedora: [
      { name: "Fedora 42", slug: "fedora-42-x64" },
    ],
    almalinux: [
      { name: "AlmaLinux 8", slug: "almalinux-8-x64" },
      { name: "AlmaLinux 9", slug: "almalinux-9-x64" },
    ],
    rocky: [
      { name: "Rocky Linux 8", slug: "rockylinux-8-x64" },
      { name: "Rocky Linux 9", slug: "rockylinux-9-x64" },
    ]
  };

  const versionList = osVersions[osKey] || [];

  const keyboard = versionList.map(v => [{
    text: v.name,
    callback_data: `buyvps_os:${v.slug}`
  }]);

  keyboard.push([
    { text: "🔙 Kembali ke OS Family", callback_data: `buyvps_ram:${userState[userId]?.vpsData?.plan}` }
  ]);

  await editMenuMessage(ctx,
    `🖥 *OS Dipilih*: ${osKey.toUpperCase()}\n\nPilih *Versi OS*:`,
    {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard }
    }
  );
});

bot.action(/buyvps_os:(.+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_os')) return;
  
  const osSlug = ctx.match[1];
  const userId = ctx.from.id;
  
  if (userState[userId]?.vpsData) {
    userState[userId].vpsData.os = osSlug;
  }

  const regionList = [
    { name: "SINGAPORE", code: "sgp1" },
    { name: "NEW YORK", code: "nyc3" },
    { name: "SAN FRANCISCO", code: "sfo3" },
    { name: "AMSTERDAM", code: "ams3" },
    { name: "LONDON", code: "lon1" },
    { name: "FRANKFURT", code: "fra1" },
  ];

  let text = `📍 *PILIH REGION VPS*\n\n`;
  regionList.forEach((r, i) => text += `${i + 1}. ${r.name}\n`);

  if (userState[userId]?.vpsData) {
    userState[userId].vpsData.regionList = regionList;
  }

  const buttons = regionList.map((r, i) => [
    { text: `${i + 1}. ${r.name}`, callback_data: `buyvps_region:${r.code}` }
  ]);

  buttons.push([
    { text: "🔙 Kembali", callback_data: `buyvps_osfamily:${userState[userId]?.vpsData?.osFamily}` }
  ]);

  await editMenuMessage(ctx, text, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: buttons }
  });
});

bot.action(/buyvps_region:(.+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_region')) return;
  
  const region = ctx.match[1];
  const userId = ctx.from.id;
  
  if (!userState[userId]?.vpsData) {
    return ctx.answerCbQuery("❌ Session VPS tidak ditemukan!", { show_alert: true });
  }

  const vpsData = userState[userId].vpsData;
  vpsData.region = region;

  const paket = vpsData.paket;
  const plan = vpsData.plan;
  const hargaRaw = config.hargaVPS?.[paket]?.[plan] || 0;
  
  vpsData.harga = hargaRaw;
  vpsData.username = ctx.from.username || ctx.from.first_name;

  const paketInfo = {
    low: { garansi: "7 Hari", replace: "1x" },
    medium: { garansi: "15 Hari", replace: "2x" },
    high: { garansi: "30 Hari", replace: "Unlimited" }
  };

  const specList = {
    "2c2": "2GB 2 VCPU | 60GB SSD | 3TB BW",
    "4c2": "4GB 2 VCPU | 80GB SSD | 4TB BW",
    "8c4": "8GB 4 VCPU | 160GB SSD | 5TB BW",
    "16c4": "16GB 4 VCPU | 200GB SSD | 8TB BW",
    "16c8": "16GB 8 VCPU | 320GB SSD | 6TB BW"
  };

  const labelSpec = specList[plan] || "-";
  const harga = `Rp ${hargaRaw.toLocaleString("id-ID")}`;

  await editMenuMessage(ctx,
`✅ *KONFIRMASI PEMESANAN VPS*
━━━━━━━━━━━━━━━━━━━━━━

📦 *Paket*: ${paket.toUpperCase()}
💸 *Harga*: *${harga}*

🛡️ *Garansi*: ${paketInfo[paket].garansi}
♻️ *Replace*: ${paketInfo[paket].replace}

🖥 *Spesifikasi*
• ${labelSpec}
• CPU/RAM Code: *${plan}*

🧩 *OS Family*: ${vpsData.osFamily.toUpperCase()}
🖥 *OS Version*: ${vpsData.os}
🌍 *Region*: ${region}

━━━━━━━━━━━━━━━━━━━━━━
Silakan pilih metode pembayaran.`,
    {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "💰 Bayar via QRIS Otomatis", callback_data: "buyvps_pay_qris" }],
          [{ text: "🔙 Kembali", callback_data: `buyvps_os:${vpsData.os}` }]
        ]
      }
    }
  );
});

bot.action(/choose_service(_page_(\d+))?/, async (ctx) => {
  const page = ctx.match[2] ? parseInt(ctx.match[2]) : 1;
  const perPage = 20;
  const apiKey = config.RUMAHOTP;

  try {
    if (!ctx.match[2]) {
       await ctx.editMessageCaption("⏳ <b>Memuat daftar layanan...</b>", { parse_mode: "HTML" }).catch(() => {});
    }

    if (globalNokos.cachedServices.length === 0) {
      const res = await axios.get("https://www.rumahotp.com/api/v2/services", { headers: { "x-apikey": apiKey } });
      if (res.data.success) globalNokos.cachedServices = res.data.data;
    }

    const services = globalNokos.cachedServices;
    const totalPages = Math.ceil(services.length / perPage);
    const start = (page - 1) * perPage;
    const list = services.slice(start, start + perPage);

    const buttons = list.map(srv => [{
      text: `${srv.service_name}`,
      callback_data: `service_${srv.service_code}`
    }]);

    const nav = [];
    if (page > 1) nav.push({ text: "⬅️ Prev", callback_data: `choose_service_page_${page - 1}` });
    if (page < totalPages) nav.push({ text: "➡️ Next", callback_data: `choose_service_page_${page + 1}` });
    if (nav.length) buttons.push(nav);

    buttons.push([{ text: "💰 DEPOSIT (RumahOTP)", callback_data: "topup_nokos" }]); 
    buttons.push([{ text: "🔙 Kembali", callback_data: "shop_menu" }]);

    const caption = `<b>📱 DAFTAR APLIKASI OTP</b>\n\nSilakan pilih aplikasi:\nHalaman ${page}/${totalPages}`;

    globalNokos.lastServicePhoto[ctx.from.id] = { chatId: ctx.chat.id, messageId: ctx.callbackQuery.message.message_id };

    if (config.ppthumb && !ctx.match[2]) {
       await editMenuMessageWithPhoto(ctx, config.ppthumb, caption, { reply_markup: { inline_keyboard: buttons } });
    } else {
       await ctx.editMessageCaption(caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } });
    }

  } catch (error) {
    console.error(error);
    await ctx.answerCbQuery("❌ Gagal memuat layanan.");
  }
});

bot.action(/service_(.+)/, async (ctx) => {
  const serviceId = ctx.match[1];
  const apiKey = config.RUMAHOTP;

  await ctx.editMessageCaption("⏳ <b>Memuat negara...</b>", { parse_mode: "HTML" }).catch(() => {});

  try {
    if (!globalNokos.cachedCountries[serviceId]) {
      const res = await axios.get(`https://www.rumahotp.com/api/v2/countries?service_id=${serviceId}`, {
        headers: { "x-apikey": apiKey }
      });
      if (res.data.success) {
         globalNokos.cachedCountries[serviceId] = res.data.data.filter(x => x.pricelist && x.pricelist.length > 0);
      }
    }

    const countries = globalNokos.cachedCountries[serviceId] || [];
    if (countries.length === 0) return ctx.editMessageCaption("❌ Negara tidak tersedia.", { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{text: "🔙 Kembali", callback_data: "choose_service"}]] } });

    const slice = countries.slice(0, 20);
    
    const buttons = slice.map(c => [{
      text: `${c.name} (${c.stock_total})`,
      callback_data: `country_${serviceId}_${c.iso_code}_${c.number_id}`
    }]);

    buttons.push([{ text: "🔙 Kembali", callback_data: "choose_service" }]);

    await ctx.editMessageCaption(`<b>🌍 PILIH NEGARA</b>\nLayanan ID: ${serviceId}`, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons }
    });
  } catch (e) {
    ctx.answerCbQuery("Error memuat negara");
  }
});

bot.action(/country_(.+)_(.+)_(.+)/, async (ctx) => {
  const [_, serviceId, iso, numberId] = ctx.match;
  const apiKey = config.RUMAHOTP;
  const untung = config.UNTUNG_NOKOS || 500;

  await ctx.editMessageCaption("⏳ <b>Memuat harga...</b>", { parse_mode: "HTML" }).catch(() => {});

  try {
    let countryData = globalNokos.cachedCountries[serviceId]?.find(c => String(c.number_id) === String(numberId));
    
    if (!countryData) {
       const res = await axios.get(`https://www.rumahotp.com/api/v2/countries?service_id=${serviceId}`, { headers: { "x-apikey": apiKey } });
       countryData = res.data.data.find(c => String(c.number_id) === String(numberId));
    }

    if (!countryData) return ctx.answerCbQuery("Negara data error");

    const providers = (countryData.pricelist || [])
      .filter(p => p.available && p.stock > 0)
      .map(p => {
        const finalPrice = (parseInt(p.price) || 0) + untung;
        return { ...p, finalPrice };
      })
      .sort((a, b) => a.finalPrice - b.finalPrice);

    if (providers.length === 0) return ctx.editMessageCaption("❌ Stok kosong untuk negara ini.", { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{text: "🔙 Kembali", callback_data: `service_${serviceId}`}]] } });

    const buttons = providers.map(p => [{
      text: `Rp ${toRupiah(p.finalPrice)} (Stok: ${p.stock})`,
      callback_data: `buy_nokos_${numberId}_${p.provider_id}_${serviceId}_${p.finalPrice}`
    }]);

    buttons.push([{ text: "🔙 Kembali", callback_data: `service_${serviceId}` }]);

    await ctx.editMessageCaption(`<b>💵 PILIH HARGA</b>\nNegara: ${countryData.name}\n\nPilih harga terbaik:`, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons }
    });

  } catch (e) {
    ctx.answerCbQuery("Gagal memuat harga");
  }
});

bot.action(/buy_nokos_(.+)_(.+)_(.+)_(.+)/, async (ctx) => {
  const [_, numberId, providerId, serviceId, price] = ctx.match;
  
  const buttons = [
    [{ text: "✅ Konfirmasi Beli (Random Operator)", callback_data: `confirm_nokos_${numberId}_${providerId}_${serviceId}_any_${price}` }],
    [{ text: "📡 Pilih Operator Tertentu", callback_data: `operator_${numberId}_${providerId}_${serviceId}_${price}` }],
    [{ text: "🔙 Batal", callback_data: "choose_service" }]
  ];

  await ctx.editMessageCaption(`<b>🛒 KONFIRMASI ORDER</b>\n\n💰 Harga: Rp ${toRupiah(price)}\n\nLanjutkan pembelian?`, {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: buttons }
  });
});

bot.action(/operator_(.+)_(.+)_(.+)_(.+)/, async (ctx) => {
  const [_, numberId, providerId, serviceId, price] = ctx.match;
  const apiKey = config.RUMAHOTP;

  try {
     const countryData = globalNokos.cachedCountries[serviceId]?.find(c => String(c.number_id) === String(numberId));
     if (!countryData) return ctx.answerCbQuery("Data negara hilang, ulangi dari awal.");

     const res = await axios.get(`https://www.rumahotp.com/api/v2/operators?country=${encodeURIComponent(countryData.name)}&provider_id=${providerId}`, { headers: { "x-apikey": apiKey } });
     
     const ops = res.data.data || [];
     if(ops.length === 0) return ctx.answerCbQuery("Operator spesifik tidak tersedia, gunakan random.");

     const buttons = ops.map(op => [{
        text: op.name,
        callback_data: `confirm_nokos_${numberId}_${providerId}_${serviceId}_${op.id}_${price}`
     }]);
     buttons.push([{text: "🔙 Kembali", callback_data: `buy_nokos_${numberId}_${providerId}_${serviceId}_${price}`}]);

     await ctx.editMessageCaption(`<b>📡 PILIH OPERATOR</b>\nProvider ID: ${providerId}`, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: buttons }
     });

  } catch(e) {
     ctx.answerCbQuery("Gagal load operator");
  }
});

bot.action(/confirm_nokos_(.+)_(.+)_(.+)_(.+)_(.+)/, async (ctx) => {
  const [_, numberId, providerId, serviceId, operatorId, priceStr] = ctx.match;
  const price = parseInt(priceStr);
  const userId = ctx.from.id;
  const apiKey = config.RUMAHOTP;
  const dbPath = "./database/saldoOtp.json";

  const saldoData = JSON.parse(fs.readFileSync(dbPath, "utf8") || "{}");
  const userSaldo = saldoData[userId] || 0;

  if (userSaldo < price) {
    return ctx.answerCbQuery("❌ Saldo tidak cukup!", { show_alert: true });
  }

  await ctx.editMessageCaption("⏳ <b>Memproses order ke server...</b>", { parse_mode: "HTML" }).catch(()=>{});

  try {
    saldoData[userId] = userSaldo - price;
    fs.writeFileSync(dbPath, JSON.stringify(saldoData, null, 2));

    let url = `https://www.rumahotp.com/api/v2/orders?number_id=${numberId}&provider_id=${providerId}`;
    if (operatorId && operatorId !== 'any') {
        url += `&operator_id=${operatorId}`;
    }

    const res = await axios.get(url, { headers: { "x-apikey": apiKey } });

    if (!res.data.success) {
      saldoData[userId] += price;
      fs.writeFileSync(dbPath, JSON.stringify(saldoData, null, 2));
      
      const errMsg = res.data.message || "Stok habis / Gangguan Provider";
      return ctx.editMessageCaption(`❌ <b>Order Gagal:</b> ${errMsg}\n💰 Saldo dikembalikan.`, { 
          parse_mode: "HTML", 
          reply_markup: { inline_keyboard: [[{text:"🔙 Menu", callback_data:"choose_service"}]] } 
      });
    }

    const d = res.data.data;
    
    globalNokos.activeOrders[d.order_id] = {
      userId,
      price,
      messageId: ctx.callbackQuery.message.message_id,
      startTime: Date.now()
    };

    const text = `✅ <b>ORDER BERHASIL</b>\n\n🆔 ID: <code>${d.order_id}</code>\n📞 No: <code>${d.phone_number}</code>\n📱 App: ${d.service}\n💰 Harga: ${toRupiah(price)}\n\n⏳ <i>Menunggu SMS OTP...</i>`;

    await ctx.editMessageCaption(text, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "📩 Cek Kode SMS", callback_data: `check_sms_${d.order_id}` }],
          [{ text: "❌ Batalkan Pesanan", callback_data: `cancel_sms_${d.order_id}` }]
        ]
      }
    });

    const expireTime = (d.expires_in_minute || 20) * 60 * 1000;
    
    setTimeout(async () => {
       if (globalNokos.activeOrders[d.order_id]) {
           try {
               const cek = await axios.get(`https://www.rumahotp.com/api/v1/orders/get_status?order_id=${d.order_id}`, { headers: { "x-apikey": apiKey } });
               const st = cek.data.data;

               if (st.status !== 'completed' && (!st.otp_code || st.otp_code === '-')) {
                   await axios.get(`https://www.rumahotp.com/api/v1/orders/set_status?order_id=${d.order_id}&status=cancel`, { headers: { "x-apikey": apiKey } });
                   
                   const curSaldo = JSON.parse(fs.readFileSync(dbPath, "utf8"));
                   curSaldo[userId] = (curSaldo[userId] || 0) + price;
                   fs.writeFileSync(dbPath, JSON.stringify(curSaldo, null, 2));

                   bot.telegram.sendMessage(userId, `⌛ <b>Order Expired/Timeout</b>\nID: ${d.order_id}\nSaldo Rp ${toRupiah(price)} dikembalikan.`, {parse_mode:"HTML"});
                   
                   delete globalNokos.activeOrders[d.order_id];
               }
           } catch(e) { console.log("Auto cancel error", e.message); }
       }
    }, expireTime);

  } catch (e) {
    console.error("Order Sys Error:", e);
    const curSaldo = JSON.parse(fs.readFileSync(dbPath, "utf8"));
    curSaldo[userId] = (curSaldo[userId] || 0) + price;
    fs.writeFileSync(dbPath, JSON.stringify(curSaldo, null, 2));
    ctx.editMessageCaption(`❌ <b>System Error:</b> ${e.message}`);
  }
});

bot.action(/check_sms_(.+)/, async (ctx) => {
  const orderId = ctx.match[1];
  const apiKey = config.RUMAHOTP;

  try {
    const res = await axios.get(`https://www.rumahotp.com/api/v1/orders/get_status?order_id=${orderId}`, {
       headers: { "x-apikey": apiKey }
    });

    const d = res.data.data;
    const status = d.status.toLowerCase();

    if (status === "completed" || (d.otp_code && d.otp_code !== "-")) {
       if (globalNokos.activeOrders[orderId]) delete globalNokos.activeOrders[orderId];
       
       await ctx.editMessageCaption(
           `✅ <b>SMS DITERIMA!</b>\n\n📞 No: <code>${d.phone_number}</code>\n💬 <b>OTP:</b> <code>${d.otp_code}</code>\n\n<i>Transaksi Selesai.</i>`, 
           { parse_mode: "HTML" }
       );
       return;
    } 
    
    if (status === 'processing' || status === 'waiting' || status === 'pending') {
       const sisaWaktu = d.expires_in ? `(${d.expires_in}s)` : "";
       return ctx.answerCbQuery(`⏳ SMS Belum masuk.. Tunggu sebentar lagi! ${sisaWaktu}`, { show_alert: false });
    } 
    
    if (status === 'cancelled' || status === 'expired') {
       if (globalNokos.activeOrders[orderId]) delete globalNokos.activeOrders[orderId];
       await ctx.editMessageCaption(`❌ <b>Order Dibatalkan/Expired.</b>`, { parse_mode: "HTML" });
       return;
    }

    await ctx.answerCbQuery(`Status: ${status}`);

  } catch(e) {
    console.error("Check SMS Error:", e.message);
    ctx.answerCbQuery("⚠️ Gagal cek status API.");
  }
});

bot.action(/cancel_sms_(.+)/, async (ctx) => {
  const orderId = ctx.match[1];
  const apiKey = config.RUMAHOTP;
  const userId = ctx.from.id;

  let orderInfo = globalNokos.activeOrders[orderId];

  try {
    const res = await axios.get(`https://www.rumahotp.com/api/v1/orders/set_status?order_id=${orderId}&status=cancel`, {
       headers: { "x-apikey": apiKey }
    });

    if (res.data.success) {
       let msgRefund = "";

       if (orderInfo) {
          const dbPath = "./database/saldoOtp.json";
          const saldoData = JSON.parse(fs.readFileSync(dbPath, "utf8") || "{}");
          
          saldoData[userId] = (saldoData[userId] || 0) + orderInfo.price;
          fs.writeFileSync(dbPath, JSON.stringify(saldoData, null, 2));
          
          delete globalNokos.activeOrders[orderId];
          msgRefund = `\n💰 Saldo Rp ${toRupiah(orderInfo.price)} telah dikembalikan.`;
       } else {
          msgRefund = "\n⚠️ Data lokal hilang (bot restart), saldo tidak otomatis kembali. Hubungi Admin.";
       }

       await ctx.editMessageCaption(`✅ <b>Order Berhasil Dibatalkan.</b>${msgRefund}`, { 
           parse_mode: "HTML", 
           reply_markup: { inline_keyboard: [[{text:"🔙 Menu Utama", callback_data:"choose_service"}]] } 
       });

    } else {
       ctx.answerCbQuery("❌ Gagal cancel: " + (res.data.message || "Mungkin sudah expired/completed."));
    }
  } catch(e) {
    console.error("Cancel Error:", e.message);
    ctx.answerCbQuery("❌ Terjadi kesalahan API.");
  }
});

bot.action("topup_nokos", async (ctx) => {
  userState[ctx.from.id] = { step: "WAITING_TOPUP_RUMAHOTP" };
  await editMenuMessage(ctx, 
    "<b>💳 DEPOSIT (Qris RumahOTP)</b>\n\nSilakan kirim nominal deposit (Hanya Angka).\nMinimal: Rp 2.000\nContoh: <code>10000</code>", 
    { 
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [[{text: "❌ Batal", callback_data: "choose_service"}]] }
    }
  );
});

bot.action(/batal_depo_rumahotp_(.+)/, async (ctx) => {
   const depoId = ctx.match[1];
   const apiKey = config.RUMAHOTP;
   try {
     await axios.get(`https://www.rumahotp.com/api/v1/deposit/cancel?deposit_id=${depoId}`, { headers: { "x-apikey": apiKey } });
     await ctx.deleteMessage();
     await ctx.reply("✅ Deposit dibatalkan.", {reply_markup: {inline_keyboard: [[{text:"🔙 Menu", callback_data:"choose_service"}]]}});
   } catch(e) {
     ctx.answerCbQuery("Gagal batal");
   }
});

bot.action("add_script", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  userState[ctx.from.id] = { step: "WAITING_SCRIPT_FILE" };
  safeReply(ctx, `<blockquote><b>📥 CARA TAMBAH SCRIPT</b>\n\n<b>1. Silahkan kirim file *.zip* sekarang.</b>\n<b>2. Setelah file terkirim, bot akan meminta detail produk.</b></blockquote>`,
    { parse_mode: "HTML", ...Markup.inlineKeyboard([[Markup.button.callback("🔙 Batal", "menu_owner")]]) }
  );
});

bot.action("add_app", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  userState[ctx.from.id] = { step: "WAITING_APP_TEXT" };
  safeReply(ctx, "<blockquote><b>✏️ Kirim detail App Premium dengan format:</b>\n<code>Nama | Harga | Deskripsi</code>\n\n<b>Contoh:</b>\n<code>CANVA PRO | 3500 | Akses premium aktif</code></blockquote>", { parse_mode: "HTML" });
});

bot.action("del_script", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  const db = readDb();
  if (db.scripts.length === 0) return ctx.editMessageText("Belum ada produk script.", Markup.inlineKeyboard([[Markup.button.callback("🔙 Kembali", "menu_owner")]]));

  const buttons = db.scripts.map((sc, i) => [Markup.button.callback(`❌ ${sc.nama}`, `delete_sc_${i}`)]);
  buttons.push([Markup.button.callback("🔙 Kembali", "menu_owner")]);
  ctx.editMessageText("<blockquote><b>🗑️ Pilih script yang mau dihapus:</b></blockquote>", { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) })
    .catch(() => {
      safeReply(ctx, "<blockquote><b>🗑️ Pilih script yang mau dihapus:</b></blockquote>", { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
    });
});

bot.action("del_app", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  const db = readDb();
  if ((db.apps || []).length === 0) return ctx.editMessageText("Belum ada app.", Markup.inlineKeyboard([[Markup.button.callback("🔙 Kembali", "menu_owner")]]));

  const buttons = db.apps.map((a, i) => [Markup.button.callback(`❌ ${a.nama}`, `delete_app_${i}`)]);
  buttons.push([Markup.button.callback("🔙 Kembali", "menu_owner")]);
  ctx.editMessageText("<blockquote><b>🗑️ Pilih app yang mau dihapus:</b></blockquote>", { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
});

bot.action("list_apps", (ctx) => {
  const db = readDb();
  if ((db.apps || []).length === 0) return safeReply(ctx, "Tidak ada app.");
  const isOwner = ctx.from.id === config.ownerId;
  db.apps.forEach((x, i) => {
    const stock = (x.accounts || []).length;
    const text = `<blockquote><b>📱 ${x.nama}</b>\n<b>Harga:</b> ${toRupiah(x.harga)}\n<b>Stock:</b> ${stock}\n${x.deskripsi || ''}</blockquote>`;
    const buttons = [];
    if (isOwner) {
      buttons.push([ Markup.button.callback("📄 List Account", `list_accounts_${i}`) ]);
    }
    safeReply(ctx, text, { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
  });
});

bot.action("buyvps_pay_qris", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_pay_qris')) return;
  
  const userId = ctx.from.id;
  
  if (!userState[userId]?.vpsData) {
    return ctx.answerCbQuery("❌ Data VPS tidak ditemukan!", { show_alert: true });
  }

  const vpsData = userState[userId].vpsData;
  const nominal = vpsData.harga;
  const itemName = `VPS ${vpsData.paket.toUpperCase()} - ${vpsData.plan} - ${vpsData.region}`;

  await handlePayment(ctx, nominal, itemName, {
    type: "vps",
    vpsData: vpsData
  });
});

bot.action(/buy_sc_(\d+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buy_sc')) return;
  
  const index = parseInt(ctx.match[1]);
  const db = readDb();
  const item = db.scripts[index];
  if (!item || !item.file_id) return safeReply(ctx, "Script tidak ditemukan/file hilang.");
  
  await handlePayment(ctx, item.harga, "Script: " + item.nama, {
    type: "script",
    index: index
  });
});

bot.action(/buy_app_(\d+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buy_app')) return;
  
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  const app = db.apps[idx];
  if (!app) return ctx.answerCbQuery("❌ App tidak ditemukan.");
  const stock = (app.accounts || []).length;
  if (stock <= 0) return ctx.answerCbQuery("❌ Stock habis.");

  userState[ctx.from.id] = {
    step: "PURCHASE_APP",
    appIndex: idx,
    qty: 1,
    message: null
  };

  const base = parseInt(app.harga) || 0;
  const qty = 1;
  const total = calcTotalPrice(base, qty);
  const caption = renderPurchaseText(app, qty, total);
  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [ 
          { text: "➖", callback_data: `app_qty_minus_${idx}` }, 
          { text: `${qty}`, callback_data: `app_qty_show_${idx}` }, 
          { text: "➕", callback_data: `app_qty_plus_${idx}` } 
        ],
        [ { text: "🛒 Buy Now", callback_data: `app_buy_now_${idx}` } ],
        [ { text: "🔙 Batal", callback_data: "back_home" } ]
      ]
    }
  };

  await editMenuMessage(ctx, caption, {
    parse_mode: "HTML",
    ...keyboard
  });
  
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/app_qty_minus_(\d+)/, async (ctx) => {
  const uid = ctx.from.id;
  const idx = parseInt(ctx.match[1]);
  if (!userState[uid] || userState[uid].step !== "PURCHASE_APP" || userState[uid].appIndex !== idx) {
    userState[uid] = { step: "PURCHASE_APP", appIndex: idx, qty: 1, message: null };
  }
  const db = readDb();
  const app = db.apps[idx];
  if (!app) {
    ctx.answerCbQuery("❌ App tidak ditemukan.");
    return;
  }
  userState[uid].qty = Math.max(1, (userState[uid].qty || 1) - 1);
  const qty = userState[uid].qty;
  const base = parseInt(app.harga) || 0;
  const stock = (app.accounts || []).length;
  if (qty > stock) userState[uid].qty = stock;
  const total = calcTotalPrice(base, userState[uid].qty);
  const caption = renderPurchaseText(app, userState[uid].qty, total);

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [ 
          { text: "➖", callback_data: `app_qty_minus_${idx}` }, 
          { text: `${userState[uid].qty}`, callback_data: `app_qty_show_${idx}` }, 
          { text: "➕", callback_data: `app_qty_plus_${idx}` } 
        ],
        [ { text: "🛒 Buy Now", callback_data: `app_buy_now_${idx}` } ],
        [ { text: "🔙 Batal", callback_data: "back_home" } ]
      ]
    }
  };

  await editMenuMessage(ctx, caption, {
    parse_mode: "HTML",
    ...keyboard
  });
  
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/app_qty_plus_(\d+)/, async (ctx) => {
  const uid = ctx.from.id;
  const idx = parseInt(ctx.match[1]);
  if (!userState[uid] || userState[uid].step !== "PURCHASE_APP" || userState[uid].appIndex !== idx) {
    userState[uid] = { step: "PURCHASE_APP", appIndex: idx, qty: 1, message: null };
  }
  const db = readDb();
  const app = db.apps[idx];
  if (!app) {
    ctx.answerCbQuery("❌ App tidak ditemukan.");
    return;
  }
  const stock = (app.accounts || []).length;
  userState[uid].qty = (userState[uid].qty || 1) + 1;
  if (userState[uid].qty > stock) userState[uid].qty = stock;
  const total = calcTotalPrice(parseInt(app.harga) || 0, userState[uid].qty);
  const caption = renderPurchaseText(app, userState[uid].qty, total);

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [ 
          { text: "➖", callback_data: `app_qty_minus_${idx}` }, 
          { text: `${userState[uid].qty}`, callback_data: `app_qty_show_${idx}` }, 
          { text: "➕", callback_data: `app_qty_plus_${idx}` } 
        ],
        [ { text: "🛒 Buy Now", callback_data: `app_buy_now_${idx}` } ],
        [ { text: "🔙 Batal", callback_data: "back_home" } ]
      ]
    }
  };

  await editMenuMessage(ctx, caption, {
    parse_mode: "HTML",
    ...keyboard
  });
  
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/app_qty_show_(\d+)/, (ctx) => {
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/app_buy_now_(\d+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'app_buy_now')) return;
  
  const uid = ctx.from.id;
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  const app = db.apps[idx];
  if (!app) return ctx.answerCbQuery("❌ App tidak ditemukan.");
  const stock = (app.accounts || []).length;
  const st = userState[uid];
  if (!st || st.step !== "PURCHASE_APP" || st.appIndex !== idx) {
    userState[uid] = { step: "PURCHASE_APP", appIndex: idx, qty: 1, message: null };
  }
  const qty = Math.max(1, userState[uid].qty || 1);
  if (qty > stock) return ctx.answerCbQuery("❌ Jumlah melebihi stock.");
  const total = calcTotalPrice(parseInt(app.harga) || 0, qty);

  await handlePayment(ctx, total, `App: ${app.nama} x${qty}`, {
    type: "app",
    idx: idx,
    qty: qty,
    total: total
  });

  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/pay_panel_(\d+)_(\d+)_(.+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'pay_panel')) return;
  
  const ram = parseInt(ctx.match[1]);
  const price = parseInt(ctx.match[2]);
  const username = ctx.match[3];

  await handlePayment(ctx, price, `Panel ${ram === 0 ? "Unlimited" : ram/1024 + "GB"}`, {
    type: "panel",
    username: username,
    ram: ram,
    price: price
  });
});

bot.on('audio', async (ctx) => {
  console.log('Audio File ID:', ctx.message.audio.file_id);
  console.log('Audio Metadata:', {
    title: ctx.message.audio.title,
    performer: ctx.message.audio.performer,
    duration: ctx.message.audio.duration
  });
});

bot.on("text", async (ctx, next) => {
  const userId = ctx.from.id;
  const text = ctx.message.text;

  if (["📁 ☇ 𝗦𝗰𝗿𝗶𝗽𝘁", "📱 ☇ 𝗔𝗽𝗽𝘀", "📡 ☇ 𝗣𝗮𝗻𝗲𝗹", "🛠 ☇ 𝗧𝗼𝗼𝗹𝘀", "🌸 ☇ 𝗢𝘄𝗻𝗲𝗿"].includes(text)) {
    return next();
  }
  if (userState[userId]?.step === "WAITING_WD_RUMAHOTP_NOMINAL") {
    const nominal = parseInt(text.replace(/[^0-9]/g, ''));

    if (isNaN(nominal) || nominal < 1000) {
      return safeReply(ctx, "<blockquote>❌ <b>Nominal tidak valid!</b>\nMasukkan angka saja (Min 1000).</blockquote>", { parse_mode: "HTML" });
    }

    delete userState[userId];

    const waitMsg = await safeReply(ctx, "⏳ <b>Sedang menembak API H2H RumahOTP...</b>", { parse_mode: "HTML" });

    try {
      const res = await rumahOtpTransfer(nominal, config);

      const trxId = res.data?.id || res.id || "Unknown";
      const status = res.data?.status || res.status || "Pending";
      const message = res.message || "Permintaan dikirim";

      let replyText = `<blockquote>✅ <b>WD RUMAHOTP SUKSES!</b>\n\n`;
      replyText += `<b>Nominal:</b> ${toRupiah(nominal)}\n`;
      replyText += `<b>Tujuan:</b> ${config.wd_balance.destination_number} (${config.wd_balance.bank_code})\n`;
      replyText += `<b>Trx ID:</b> <code>${trxId}</code>\n`;
      replyText += `<b>Status:</b> <code>${status.toUpperCase()}</code>\n`;
      replyText += `<b>Note:</b> ${message}</blockquote>`;

      await ctx.telegram.editMessageText(ctx.chat.id, waitMsg.message_id, null, replyText, {
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [[{ text: "🔙 Menu Owner", callback_data: "menu_owner" }]]
        }
      });

    } catch (err) {
      console.error("WD RumahOTP Fail:", err);

      await ctx.telegram.editMessageText(ctx.chat.id, waitMsg.message_id, null,
        `<blockquote>❌ <b>GAGAL WD RUMAHOTP</b>\n\n<b>Error:</b> ${err.message}\n\n<i>Pastikan saldo RumahOTP cukup dan Endpoint API benar.</i></blockquote>`,
        {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [[{ text: "🔙 Menu Owner", callback_data: "menu_owner" }]]
            }
        }
      );
    }
    return;
  }
  
  if (userState[userId]?.step === "WAITING_TOPUP_RUMAHOTP") {
    const amount = parseInt(text);
    if (isNaN(amount) || amount < 2000) {
       return safeReply(ctx, "❌ Minimal deposit Rp 2.000 dan harus angka!");
    }
    
    delete userState[userId];

    const loading = await safeReply(ctx, "🔄 <b>Membuat QRIS RumahOTP...</b>", { parse_mode: "HTML" });
    const apiKey = config.RUMAHOTP;
    const fee = config.UNTUNG_DEPOSIT || 500;
    const totalRequest = amount + fee;

        try {
       const res = await axios.get(`https://www.rumahotp.com/api/v2/deposit/create?amount=${totalRequest}&payment_id=qris`, {
          headers: { "x-apikey": apiKey }
       });
       
       await ctx.deleteMessage(loading.message_id).catch(()=>{});

       if (!res.data.success) {
          return safeReply(ctx, "❌ Gagal membuat QRIS. Coba lagi nanti.");
       }

       const d = res.data.data;
       const caption = `<b>💳 TAGIHAN DEPOSIT</b>\n\n🆔 ID: <code>${d.id}</code>\n💰 Total Bayar: <b>Rp ${toRupiah(d.total)}</b>\n(Termasuk biaya admin)\n\n📥 Masuk Saldo: Rp ${toRupiah(amount)}\n\n⚠️ <b>Bayar sesuai nominal TOTAL (sampai digit terakhir)!</b>\nOtomatis cek status...`;
       
       const msgQris = await ctx.replyWithPhoto(d.qr_image, {
          caption: caption,
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: [[{text: "❌ Batalkan", callback_data: `batal_depo_rumahotp_${d.id}`}]] }
       });

       let checks = 0;
       const maxChecks = 120;
       const checkInterval = setInterval(async () => {
          checks++;
          if (checks > maxChecks) {
             clearInterval(checkInterval);
             return;
          }

          try {
             const checkRes = await axios.get(`https://www.rumahotp.com/api/v2/deposit/get_status?deposit_id=${d.id}`, { headers: { "x-apikey": apiKey } });
             
             if (checkRes.data && checkRes.data.success) {
                 const status = checkRes.data.data.status;

                 if (status === 'success' || status === 'paid') {
                     clearInterval(checkInterval);
                     
                     const dbPath = "./database/saldoOtp.json";
                     let saldoDB = {};
                     try { saldoDB = JSON.parse(fs.readFileSync(dbPath, "utf8")); } catch(e){}
                     
                     saldoDB[userId] = (saldoDB[userId] || 0) + amount;
                     fs.writeFileSync(dbPath, JSON.stringify(saldoDB, null, 2));

                     await ctx.deleteMessage(msgQris.message_id).catch(()=>{});
                     await ctx.reply(`✅ <b>DEPOSIT SUKSES!</b>\n\n💰 Diterima: Rp ${toRupiah(amount)}\n💼 Total Saldo: Rp ${toRupiah(saldoDB[userId])}`, { parse_mode: "HTML" });
                     
                     bot.telegram.sendMessage(config.ownerId, `🔔 User ${userId} Deposit Rp ${amount} via RumahOTP`).catch(()=>{});

                 } else if (status === 'cancelled' || status === 'failed') {
                     clearInterval(checkInterval);
                     await ctx.deleteMessage(msgQris.message_id).catch(()=>{});
                     await ctx.reply("❌ Deposit dibatalkan/gagal.");
                 }
             }
          } catch(e) { 
              console.log("Error cek deposit:", e.message);
          }
       }, 5000);

    } catch(e) {
       console.error(e);
       safeReply(ctx, "❌ Error API RumahOTP");
    }
    return;
  }
  
  if (userState[userId]?.step === "WAITING_USERNAME_PANEL") {
    if (!/^[a-zA-Z0-9]+$/.test(text))
        return ctx.reply("<blockquote>⚠️ <b>Username hanya boleh huruf & angka!</b></blockquote>", { parse_mode: "HTML" });

    const username = text;
    delete userState[userId].step;

    const hargaGb = config.hargaPanel.perGB;
    const hargaUnli = config.hargaPanel.unlimited;

    let listRam = [];

    for (let gb = 1; gb <= 10; gb++) {
        const ramMB = gb * 1024;
        const price = gb * hargaGb;

        listRam.push({
            label: `${gb}GB - ${toRupiah(price)}`,
            ram: ramMB,
            price
        });
    }

    listRam.push({
        label: `UNLIMITED (${toRupiah(price)})`,
        ram: 0,
        price: 5000
    });

    const buttons = listRam.map(p => {
        return [{ text: p.label, callback_data: `pay_panel_${p.ram}_${p.price}_${username}` }];
    });

    buttons.push([{ text: "🔙 Batal", callback_data: "back_home" }]);

    return ctx.reply(
        `<blockquote><b>🛠️ Pilih Spesifikasi untuk user ${username}</b></blockquote>`,
        {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: buttons }
        }
    );
  }

  if (userState[userId]?.step === "WAITING_SCRIPT_DETAIL") {
  const state = userState[userId];
  const parts = text.split("|").map(x => x.trim());
  
  if (parts.length !== 3) {
    return safeReply(ctx, "<blockquote>❌ Format detail salah! Gunakan: Nama | Harga (angka) | Deskripsi</blockquote>", { parse_mode: "HTML" });
  }
  
  const [nama, hargaStr, deskripsi] = parts;
  const harga = parseInt(hargaStr);
  
  if (isNaN(harga) || harga <= 0) {
    return safeReply(ctx, "<blockquote>❌ Harga harus angka positif!</blockquote>", { parse_mode: "HTML" });
  }
  
  try {
    const db = readDb();
    const scriptData = {
      nama: nama,
      harga: harga,
      deskripsi: deskripsi,
      file_id: state.file_id, 
      fileName: state.temp_fileName 
    };
    
    db.scripts.push(scriptData);
    saveDb(db);
    
    const addedBy = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
    
    sendProductNotification("script", scriptData, addedBy);
    
    safeReply(ctx, `<blockquote><b>✅ Sukses Menambah Script!</b>\n\n<b>📂 Nama:</b> <code>${nama}</code>\n<b>💰 Harga:</b> <code>${toRupiah(harga)}</code>\n<b>📄 File:</b> <code>${state.temp_fileName}</code>\n\n📢 Notifikasi telah dikirim ke channel!</blockquote>`, { 
      parse_mode: "HTML" 
    });
    
  } catch (e) {
    console.error(e);
    safeReply(ctx, "❌ Gagal menyimpan data script ke database.");
  }
  
  delete userState[userId];
  return;
}

  if (userState[userId]?.step === "WAITING_APP_TEXT") {
  if (userId !== config.ownerId) return next();
  
  const parts = text.split("|").map(x => x.trim());
  if (parts.length !== 3) {
    return safeReply(ctx, "<blockquote>❌ Format salah! Gunakan: Nama | Harga | Deskripsi</blockquote>", { parse_mode: "HTML" });
  }
  
  const [nama, hargaStr, deskripsi] = parts;
  const harga = parseInt(hargaStr);
  
  if (isNaN(harga) || harga <= 0) {
    return safeReply(ctx, "<blockquote>❌ Harga harus angka positif!</blockquote>", { parse_mode: "HTML" });
  }
  
  try {
    const db = readDb();
    const newApp = {
      nama,
      harga,
      deskripsi,
      accounts: [] 
    };
    
    db.apps.push(newApp);
    saveDb(db);
    const idx = db.apps.length - 1;
    
    const addedBy = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
    
    sendProductNotification("app", newApp, addedBy);
    
    await safeReply(ctx, `<blockquote><b>✅ App Premium ditambahkan!</b>\n<b>📱 ${nama}</b>\n<b>Stock:</b> 0\n\n📢 Notifikasi telah dikirim ke channel!</blockquote>`, {
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        [ Markup.button.callback("📄 List Account", `list_accounts_${idx}`) ],
        [ Markup.button.callback("🔙 Kembali ke Owner Menu", "menu_owner") ]
      ])
    });
    
  } catch (e) {
    console.error(e);
    safeReply(ctx, "❌ Gagal menyimpan data app ke database.");
  }
  
  delete userState[userId];
  return;
}

  if (userState[userId]?.step === "WAITING_ADD_ACCOUNT") {
  if (userId !== config.ownerId) return next();
  
  const st = userState[userId];
  const parts = text.split("|").map(x => x.trim());
  
  if (parts.length !== 4) {
    return safeReply(ctx, "<blockquote>❌ Format salah! Gunakan: username|password|link akses|deskripsi</blockquote>", { parse_mode: "HTML" });
  }
  
  const [usernameA, passwordA, linkA, descA] = parts;
  
  try {
    const db = readDb();
    const app = db.apps[st.appIndex];
    
    if (!app) {
      return safeReply(ctx, "❌ App tidak ditemukan / sudah dihapus.");
    }
    
    app.accounts = app.accounts || [];
    app.accounts.push({ 
      user: usernameA, 
      pass: passwordA, 
      link: linkA, 
      desc: descA 
    });
    
    saveDb(db);
    const stockNow = app.accounts.length;
    
    const addedBy = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
    const accountData = {
      appName: app.nama,
      username: usernameA,
      password: passwordA,
      link: linkA,
      desc: descA,
      newStock: stockNow
    };
    
    sendProductNotification("account", accountData, addedBy);
    
    safeReply(ctx, `<blockquote><b>✅ Akun ditambahkan!</b>\n<b>Stock sekarang:</b> ${stockNow}\n\n📢 Notifikasi telah dikirim ke channel!</blockquote>`, {
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        [ Markup.button.callback("➕ Tambah lagi", `owner_add_account`) ],
        [ Markup.button.callback("📃 List App Premium", "list_apps") ],
        [ Markup.button.callback("🔙 Kembali ke Owner Menu", "menu_owner") ]
      ])
    });
    
  } catch (e) {
    console.error(e);
    safeReply(ctx, "❌ Gagal menambahkan akun ke database.");
  }
  
  delete userState[userId];
  return;
}

  if (userState[ctx.from.id]?.step === "WAITING_BROADCAST" && ctx.from.id === config.ownerId) {
    const users = loadUsers();
    let sent = 0;
    for (const uid of users) {
      try {
        if (ctx.message.photo) {
          await bot.telegram.sendPhoto(uid, ctx.message.photo[0].file_id, { caption: ctx.message.caption || "", parse_mode: "HTML" });
        } else if (ctx.message.document) {
          await bot.telegram.sendDocument(uid, ctx.message.document.file_id, { caption: ctx.message.caption || "", parse_mode: "HTML" });
        } else {
          await bot.telegram.sendMessage(uid, ctx.message.text);
        }
        sent++;
      } catch (e) {}
    }
    delete userState[ctx.from.id];
    return safeReply(ctx, `<blockquote>📢 <b>Broadcast selesai!</b> <b>Terkirim:</b> ${sent}</blockquote>`, { parse_mode: "HTML" });
  }

  return next();
});

async function downloadQrisImage(url) {
  try {
    console.log("[DEBUG] Downloading QRIS image from:", url);
    
    if (!url || !url.startsWith('http')) {
      throw new Error('URL QRIS tidak valid: ' + url);
    }
    
    const response = await axios({
      method: 'GET',
      url: url,
      responseType: 'arraybuffer',
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    
    if (!response.data || response.data.length === 0) {
      throw new Error('Gambar QRIS kosong');
    }
    
    console.log("[DEBUG] QRIS image downloaded successfully, size:", response.data.length, "bytes");
    return Buffer.from(response.data);
    
  } catch (error) {
    console.error("[ERROR] Failed to download QRIS image:", error.message);
    console.error("[ERROR] URL:", url);
    return null;
  }
}

async function handlePayment(ctx, nominal, itemName, productData) {
  if (!isPrivateChat(ctx)) {
    await ctx.answerCbQuery?.();
    return safeReply(ctx, "❌ <b>Pembayaran hanya bisa dilakukan di Private Chat!</b>\n\n💬 Silakan chat saya di private: https://t.me/" + bot.botInfo.username, { parse_mode: "HTML" });
  }
  
  const userId = ctx.from.id;
  if (activeTransactions[userId]) return safeReply(ctx, "<blockquote>⚠️ <b>Ada transaksi pending.</b> Ketik /cancel.</blockquote>", { parse_mode: "HTML" });
  
  const activePaymentMethod = getActivePaymentMethod();
  
  if (activePaymentMethod === "manual") {
    if (!config.manualQrisPhoto) {
      return safeReply(ctx, "<blockquote>❌ <b>QRIS manual belum diatur oleh owner.</b> Silakan hubungi owner.</blockquote>", { parse_mode: "HTML" });
    }
    
    const fee = Math.floor(Math.random() * 100);
    const totalBayar = nominal + fee;
    
    await ctx.replyWithPhoto(config.manualQrisPhoto, {
      caption: `<blockquote><b>🧾 TAGIHAN MANUAL</b>\n\n<b>Item:</b> <code>${itemName}</code>\n<b>Total:</b> ${toRupiah(totalBayar)}\n\n<i>Silakan transfer sesuai nominal di atas</i>\n<i>Lalu kirim foto bukti transfer ke bot ini</i>\n<i>Bot akan otomatis mengirim ke owner</i></blockquote>`,
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("❌ Batalkan", "cancel_trx")]
      ])
    });
    
    userState[userId] = {
      step: "PAYMENT_MANUAL_PENDING",
      itemName: itemName,
      amount: totalBayar,
      productData: productData,
      nominal: nominal
    };
    
    return;
  }
  
  const fee = Math.floor(Math.random() * 100);
  const totalBayar = nominal + fee;
  const msgLoading = await safeReply(ctx, "<blockquote>🔄 <b>Membuat QRIS...</b></blockquote>", { parse_mode: "HTML" });
  
  let paymentConfig = {};
  if (activePaymentMethod === "atlantic") {
    paymentConfig = { 
      method: "atlantic", 
      apiAtlantic: config.payment?.apiAtlantic || config.apikeyAtlantic || config.ApikeyAtlantic || config.apiAtlantic 
    };
  } else {
    paymentConfig = Object.assign({ method: "orkut" }, config.payment || {});
  }
  
  const qrisData = await createdQris(totalBayar, paymentConfig);
  
  try {
    await ctx.deleteMessage(msgLoading.message_id);
  } catch (e) {}
  
  if (!qrisData) {
    return safeReply(ctx, "<blockquote>❌ <b>Gagal membuat QRIS.</b></blockquote>", { parse_mode: "HTML" });
  }
  
  console.log("[DEBUG] QRIS Data:", {
    hasImage: !!qrisData.imageqris,
    imageType: typeof qrisData.imageqris,
    isBuffer: qrisData.imageqris instanceof Buffer,
    isString: typeof qrisData.imageqris === 'string',
    hasQrString: !!qrisData.qr_string,
    fullData: qrisData
  });
  
  let photoToSend = null;
  let useLocalQR = false;
  
  if (qrisData.imageqris instanceof Buffer) {
    console.log("[DEBUG] QRIS adalah Buffer, size:", qrisData.imageqris.length);
    photoToSend = { source: qrisData.imageqris };
    
  } else if (qrisData.imageqris && typeof qrisData.imageqris === 'string') {
    if (qrisData.imageqris.startsWith('data:image')) {
      try {
        console.log("[DEBUG] QRIS adalah Base64");
        const base64Data = qrisData.imageqris.replace(/^data:image\/\w+;base64,/, '');
        photoToSend = { source: Buffer.from(base64Data, 'base64') };
      } catch (e) {
        console.error("[ERROR] Failed to parse base64 image:", e.message);
      }
      
    } else if (qrisData.imageqris.startsWith('http')) {
      console.log("[DEBUG] QRIS adalah URL:", qrisData.imageqris);
      
      try {
        const { downloadQrisImage } = require("./lib/payment");
        const qrBuffer = await downloadQrisImage(qrisData.imageqris);
        
        if (qrBuffer) {
          console.log("[DEBUG] QRIS downloaded successfully, size:", qrBuffer.length);
          photoToSend = { source: qrBuffer };
        } else {
          console.log("[DEBUG] Failed to download QRIS, will use qr_string");
          useLocalQR = true;
        }
      } catch (downloadErr) {
        console.error("[ERROR] Failed to download QRIS image:", downloadErr.message);
        useLocalQR = true;
      }
    } else {
      console.log("[DEBUG] QRIS adalah string biasa");
      useLocalQR = true;
    }
  }
  
  if (!photoToSend && (useLocalQR || !qrisData.imageqris)) {
    if (qrisData.qr_string && qrisData.qr_string.trim().length > 0) {
      console.log("[DEBUG] Generating local QR from qr_string");
      try {
        const qrBuffer = await generateLocalQr(qrisData.qr_string);
        if (qrBuffer) {
          photoToSend = { source: qrBuffer };
          console.log("[DEBUG] Local QR generated successfully");
        } else {
          console.log("[DEBUG] Failed to generate local QR");
        }
      } catch (qrErr) {
        console.error("[ERROR] Failed to generate local QR:", qrErr.message);
      }
    }
  }
  
  if (!photoToSend) {
    console.error("[ERROR] No valid QRIS data available");
    return safeReply(ctx, 
      `<b>❌ GAGAL MEMBUAT QRIS</b>\n\n` +
      `<b>Item:</b> ${itemName}\n` +
      `<b>Total:</b> ${toRupiah(totalBayar)}\n\n` +
      `<i>Silakan hubungi owner untuk pembayaran manual.</i>`,
      { parse_mode: "HTML" }
    );
  }
  
  try {
    console.log("[DEBUG] Sending QRIS to user");
    
    const msgQris = await ctx.replyWithPhoto(photoToSend, {
      caption: `<blockquote><b>🧾 TAGIHAN</b>\n\n<b>Item:</b> <code>${itemName}</code>\n<b>Total:</b> ${toRupiah(qrisData.jumlah)}\n\n<i>Bayar pas sesuai nominal!</i>\n<i>Transaksi akan otomatis terverifikasi setelah pembayaran.</i></blockquote>`,
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("❌ Batalkan", "cancel_trx")]
      ])
    });
    
    activeTransactions[userId] = { 
      id: qrisData.idtransaksi || qrisData.id, 
      amount: qrisData.jumlah, 
      status: 'pending',
      messageId: msgQris.message_id,
      paymentMethod: activePaymentMethod,
      paymentConfig: paymentConfig
    };
    
    console.log(`[DEBUG] Transaction started for user ${userId}:`, activeTransactions[userId].id);
    
    let attempts = 0;
    const maxAttempts = 72;
    
    const interval = setInterval(async () => {
      attempts++;
      
      if (!activeTransactions[userId]) {
        console.log(`[DEBUG] Transaction ${userId} cancelled, stopping check`);
        clearInterval(interval);
        return;
      }
      
      if (attempts > maxAttempts) {
        console.log(`[DEBUG] Payment timeout for user ${userId} after ${attempts} attempts`);
        clearInterval(interval);
        
        if (activeTransactions[userId]) {
          try {
            if (activeTransactions[userId].messageId) {
              await ctx.deleteMessage(activeTransactions[userId].messageId).catch(() => {});
            }
          } catch (e) {}
          
          delete activeTransactions[userId];
          await safeReply(ctx, "<blockquote>❌ <b>Waktu pembayaran habis.</b> Silakan ulangi transaksi.</blockquote>", { 
            parse_mode: "HTML" 
          });
        }
        return;
      }
      
      try {
        console.log(`[DEBUG] Checking payment status for user ${userId}, attempt ${attempts}`);
        
        const isPaid = await cekStatus(
          qrisData.idtransaksi || qrisData.id, 
          qrisData.jumlah, 
          paymentConfig
        );
        
        if (isPaid) {
          console.log(`[DEBUG] Payment confirmed for user ${userId}`);
          clearInterval(interval);
          
          try {
            if (activeTransactions[userId]?.messageId) {
              await ctx.deleteMessage(activeTransactions[userId].messageId).catch(() => {});
            }
          } catch (e) {}
          
          delete activeTransactions[userId];
          
          const userName = `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim();
          sendTestimoniKeChannel(userName, userId, itemName, nominal);
          
          try {
            await bot.telegram.sendMessage(
              config.ownerId,
              `<b>💰 PEMBAYARAN SUKSES</b>\n\n` +
              `<b>👤 User:</b> ${ctx.from.first_name} (${ctx.from.id})\n` +
              `<b>🛒 Item:</b> ${itemName}\n` +
              `<b>💵 Harga:</b> ${toRupiah(nominal)}\n` +
              `<b>📊 Status:</b> QRIS Payment (${activePaymentMethod.toUpperCase()})\n` +
              `<b>⏰ Waktu:</b> ${new Date().toLocaleString()}`,
              { parse_mode: "HTML" }
            );
          } catch (ownerErr) {
            console.error("[ERROR] Failed to notify owner:", ownerErr.message);
          }
          
          await sendProductToUser(ctx, productData);
        } else {
          console.log(`[DEBUG] Payment not yet confirmed for user ${userId}`);
        }
        
      } catch (error) {
        console.error(`[ERROR] Error checking payment status for user ${userId}:`, error.message);
        
        if (attempts > 10) {
          clearInterval(interval);
          console.error(`[ERROR] Too many errors, stopping check for user ${userId}`);
          
          if (activeTransactions[userId]) {
            delete activeTransactions[userId];
            await safeReply(ctx, "<blockquote>⚠️ <b>Terjadi gangguan sistem pembayaran.</b> Silakan hubungi owner.</blockquote>", { 
              parse_mode: "HTML" 
            });
          }
        }
      }
    }, 5000);
    
  } catch (error) {
    console.error("[ERROR] Failed to send QRIS photo:", error.message);
    
    if (activeTransactions[userId]) {
      delete activeTransactions[userId];
    }
    
    let errorMessage = `<b>⚠️ GAGAL MENAMPILKAN QRIS</b>\n\n`;
    errorMessage += `<b>Item:</b> ${itemName}\n`;
    errorMessage += `<b>Total:</b> ${toRupiah(qrisData.jumlah)}\n`;
    errorMessage += `<b>ID Transaksi:</b> ${qrisData.idtransaksi || qrisData.id || '-'}\n`;
    
    if (qrisData.qr_string && qrisData.qr_string.length < 500) {
      errorMessage += `<b>QR String:</b>\n<code>${qrisData.qr_string}</code>\n\n`;
    }
    
    errorMessage += `<i>Silakan hubungi owner untuk pembayaran manual.</i>`;
    
    await safeReply(ctx, errorMessage, { parse_mode: "HTML" });
  }
}

bot.action(/delete_sc_(\d+)/, async (ctx) => {
  try {
    const idx = parseInt(ctx.match[1]);
    const db = readDb();
    const sc = db.scripts[idx];

    if (!sc) {
      await ctx.answerCbQuery("❌ Script tidak ditemukan.");
      return;
    }

    db.scripts.splice(idx, 1);
    saveDb(db);

    await ctx.answerCbQuery("✅ Script berhasil dihapus!");
    await ctx.editMessageText("✔️ Script berhasil dihapus.", Markup.inlineKeyboard([[Markup.button.callback("🔙 Kembali", "menu_owner")]]))
      .catch(()=>{ safeReply(ctx, "✔️ Script berhasil dihapus."); });

  } catch (e) {
    console.error("delete_sc error:", e);
  }
});

bot.action(/delete_app_(\d+)/, (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  const app = db.apps[idx];
  if (!app) {
    ctx.answerCbQuery("❌ App tidak ditemukan.");
    return showOwnerMenu(ctx);
  }
  db.apps.splice(idx, 1);
  saveDb(db);
  ctx.answerCbQuery(`✅ App ${app?.nama || 'Item'} berhasil dihapus.`);
  showOwnerMenu(ctx);
});

bot.action(/list_accounts_(\d+)/, (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  const app = db.apps[idx];
  if (!app) return ctx.answerCbQuery("❌ App tidak ditemukan.");
  const accounts = app.accounts || [];
  let txt = `<b>📄 List Accounts - ${app.nama}</b>\n<b>Stock:</b> ${accounts.length}\n\n`;
  if (!accounts.length) txt += "<i>Belum ada akun.</i>\n";
  accounts.forEach((a, i) => {
    txt += `<b>${i+1}.</b> ${a.user} | ${a.pass} | ${a.link} | ${a.desc || '-'}\n`;
  });
  safeReply(ctx, txt, { parse_mode: "HTML" });
  ctx.answerCbQuery().catch(()=>{});
});

bot.action("owner_add_account", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const db = readDb();
  if (!db.apps || db.apps.length === 0) return safeReply(ctx, "<blockquote>❌ <b>Belum ada app yang terdaftar.</b> Tambahkan app terlebih dahulu.</blockquote>", { parse_mode: "HTML" });
  const buttons = db.apps.map((a, i) => [ Markup.button.callback(`${a.nama} (${(a.accounts||[]).length} stok)`, `owner_add_account_to_${i}`) ]);
  buttons.push([ Markup.button.callback("🔙 Kembali", "menu_owner") ]);
  safeReply(ctx, "<blockquote><b>Pilih aplikasi untuk menambah akun:</b></blockquote>", { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/owner_add_account_to_(\d+)/, (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  if (!db.apps[idx]) return ctx.answerCbQuery("❌ App tidak ditemukan.");
  userState[ctx.from.id] = { step: "WAITING_ADD_ACCOUNT", appIndex: idx };
  safeReply(ctx, "<blockquote><b>✏️ Kirim akun dengan format:</b>\n<code>username|password|link akses|deskripsi</code></blockquote>", { parse_mode: "HTML" });
  ctx.answerCbQuery().catch(()=>{});
});

bot.action("owner_del_account", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const db = readDb();
  if (!db.apps || db.apps.length === 0) return safeReply(ctx, "<blockquote>❌ <b>Belum ada app yang terdaftar.</b></blockquote>", { parse_mode: "HTML" });
  const buttons = db.apps.map((a, i) => [ Markup.button.callback(`${a.nama} (${(a.accounts||[]).length} stok)`, `owner_del_account_choose_${i}`) ]);
  buttons.push([ Markup.button.callback("🔙 Kembali", "menu_owner") ]);
  safeReply(ctx, "<blockquote><b>Pilih aplikasi untuk menghapus akun:</b></blockquote>", { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/owner_del_account_choose_(\d+)/, (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  const app = db.apps[idx];
  if (!app) return ctx.answerCbQuery("❌ App tidak ditemukan.");
  const accounts = app.accounts || [];
  if (!accounts.length) return safeReply(ctx, "<blockquote>❌ <b>Tidak ada akun pada aplikasi ini.</b></blockquote>", { parse_mode: "HTML" });
  const buttons = accounts.map((acc, i) => [ Markup.button.callback(`🗑 ${i+1}. ${acc.user} - ${acc.desc || '-'}`, `owner_delete_acc_${idx}_${i}`) ]);
  buttons.push([ Markup.button.callback("🔙 Kembali", "menu_owner") ]);
  safeReply(ctx, `<blockquote><b>Pilih akun yang ingin dihapus dari ${app.nama}:</b></blockquote>`, { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/owner_delete_acc_(\d+)_(\d+)/, (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const appIndex = parseInt(ctx.match[1]);
  const accIndex = parseInt(ctx.match[2]);
  const db = readDb();
  const app = db.apps[appIndex];
  if (!app) return ctx.answerCbQuery("❌ App tidak ditemukan.");
  if (!app.accounts || !app.accounts[accIndex]) return ctx.answerCbQuery("❌ Akun tidak ditemukan.");
  const removed = app.accounts.splice(accIndex, 1);
  saveDb(db);
  ctx.answerCbQuery("✅ Akun dihapus.");
  safeReply(ctx, `<blockquote><b>✅ Akun ${removed[0].user} telah dihapus dari ${app.nama}</b></blockquote>`, { parse_mode: "HTML" });
});

async function sendProductToUser(ctx, productData) {
  try {
    const userId = ctx.from.id;
    const username = ctx.from.username || ctx.from.first_name;

    if (productData.type === "script") {
      const db = readDb();
      const item = db.scripts[productData.index];
      
      if (!item) {
        return safeReply(ctx, "<blockquote>❌ <b>Script tidak ditemukan!</b> Silakan hubungi owner.</blockquote>", { 
          parse_mode: "HTML" 
        });
      }
      
      if (!item.file_id) {
        return safeReply(ctx, "<blockquote>❌ <b>File script tidak tersedia!</b> Silakan hubungi owner.</blockquote>", { 
          parse_mode: "HTML" 
        });
      }
      
      await safeReply(ctx, "<blockquote>✅ <b>Pembayaran valid! Mengirim file...</b></blockquote>", { 
        parse_mode: "HTML" 
      });
      
      await ctx.replyWithDocument(item.file_id, { 
        caption: `<b>📦 ${item.nama}</b>\n\n` +
                 `<b>💰 Harga:</b> ${toRupiah(item.harga)}\n` +
                 `<b>📝 Deskripsi:</b>\n${item.deskripsi || 'Tidak ada deskripsi'}\n\n` +
                 `<i>Terima kasih telah berbelanja!</i>`, 
        filename: item.fileName || `${item.nama}.zip`,
        parse_mode: "HTML"
      });

      const userName = `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim();
      sendTestimoniKeChannel(userName, userId, `Script: ${item.nama}`, item.harga);

    } else if (productData.type === "app") {
      const db = readDb();
      const app = db.apps[productData.idx];
      
      if (!app) {
        return safeReply(ctx, "<blockquote>❌ <b>Aplikasi tidak ditemukan!</b> Silakan hubungi owner.</blockquote>", { 
          parse_mode: "HTML" 
        });
      }
      
      app.accounts = app.accounts || [];
      
      if (app.accounts.length < productData.qty) {
        return safeReply(ctx, `<blockquote>❌ <b>Stok tidak mencukupi!</b>\nStok tersedia: ${app.accounts.length}\nYang dibeli: ${productData.qty}</blockquote>`, { 
          parse_mode: "HTML" 
        });
      }
      
      const taken = [];
      for (let i = 0; i < productData.qty; i++) {
        const acc = app.accounts.shift();
        if (acc) taken.push(acc);
      }
      
      saveDb(db);
      
      let msg = `<blockquote><b>✅ Transaksi Sukses</b>\n\n<b>» Produk :</b> ${app.nama}\n<b>» Jumlah Beli :</b> ${productData.qty}\n<b>» Total Harga :</b> ${toRupiah(productData.total)}\n<b>» Deskripsi Produk :</b> ${app.deskripsi || '-'}\n\n</blockquote>`;
      
      taken.forEach((a, i) => {
        msg += `<blockquote><b>— Akun ${i+1} —</b>\n<b>Username:</b> ${a.user}\n<b>Password:</b> ${a.pass}\n<b>Link Akses:</b> ${a.link}\n<b>Deskripsi:</b> ${a.desc || '-'}\n\n</blockquote>`;
      });
      
      safeReply(ctx, msg, { parse_mode: "HTML" });

      const userName = `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim();
      sendTestimoniKeChannel(userName, userId, `App: ${app.nama} x${productData.qty}`, productData.total);

    } else if (productData.type === "panel") {
      ctx.reply("<blockquote>⏳ <b>Sedang membuat akun panel...</b></blockquote>", { parse_mode: "HTML" });
      
      let disk, cpu;
      if (productData.ram === 0) {
        disk = 0;
        cpu = 0;
      } else {
        const gb = productData.ram / 1024;
        disk = gb * 2048;
        cpu = gb * 50;
      }
      
      const result = await createPanelAccount(productData.username, productData.ram, disk, cpu);
      
      if (result.success) {
        const d = result.data;
        ctx.reply(
          `<blockquote><b>✅ PANEL BERHASIL DIBUAT</b>\n\n<b>👤 User:</b> ${productData.username}\n<b>🆔 ID:</b> <code>${d.username}</code>\n<b>🔑 PW:</b> <code>${d.password}</code>\n<b>🌐 Login:</b> ${d.login}</blockquote>`,
          { parse_mode: "HTML" }
        );

        const userName = `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim();
        sendTestimoniKeChannel(userName, userId, `Panel ${productData.ram === 0 ? "Unlimited" : productData.ram/1024 + "GB"}`, productData.price);

      } else {
        ctx.reply(`<blockquote>⚠️ <b>Gagal:</b> ${result.msg}</blockquote>`, { parse_mode: "HTML" });
      }

    } else if (productData.type === "vps") {
      const loadingMsg = await ctx.reply("<blockquote>⏳ <b>Sedang membuat VPS DigitalOcean...</b>\nProses membutuhkan waktu ±60 detik.</blockquote>", { 
        parse_mode: "HTML" 
      });
      
      try {
        productData.vpsData.username = username;
        
        const result = await createVPSDroplet(userId, productData.vpsData);
        
        try {
          await ctx.deleteMessage(loadingMsg.message_id);
        } catch (e) {}
        
        if (result.success) {
          const data = result.data;
          const paketInfo = {
            low: { garansi: 7, replace: 1 },
            medium: { garansi: 15, replace: 2 },
            high: { garansi: 30, replace: -1 }
          };
          
          const paket = productData.vpsData.paket;
          
          const detailVPS = `<blockquote>✅ <b>VPS BERHASIL DIBUAT!</b></blockquote>

<blockquote>🖥️ <b>DETAIL DATA VPS</b>
━━━━━━━━━━━━━━━━━━━━━━
<b>🌐 IP ADDRESS:</b> <code>${data.ip}</code>
<b>🆔 USERNAME:</b> <code>root</code>
<b>🔐 PASSWORD:</b> <code>${data.password}</code>
<b>🧩 HOSTNAME:</b> ${data.hostname}
<b>🌍 REGION:</b> ${data.region.toUpperCase()}
<b>💿 OS:</b> ${data.os.toUpperCase()}</blockquote>

<blockquote>🛍️ <b>DETAIL PEMBELIAN</b>
━━━━━━━━━━━━━━━━━━━━━━
<b>📦 PAKET:</b> ${paket.toUpperCase()}
<b>💾 SPESIFIKASI:</b> ${productData.vpsData.plan}
<b>💰 HARGA:</b> ${toRupiah(productData.vpsData.harga)}
<b>🛡️ GARANSI:</b> ${paketInfo[paket].garansi} Hari
<b>♻️ REPLACE:</b> ${paketInfo[paket].replace === -1 ? "Unlimited" : paketInfo[paket].replace + "x"}
<b>📅 TANGGAL:</b> ${data.created}
<b>👤 PEMBELI:</b> ${username}
<b>🤝 PENJUAL:</b> @${bot.botInfo.username}</blockquote>`;
          
          await ctx.reply(detailVPS, { parse_mode: "HTML" });
          
          await ctx.reply(
`<blockquote>📌 <b>INFORMASI PENTING</b>
━━━━━━━━━━━━━━━━━━━━━━
• Gunakan IP <code>${data.ip}</code> untuk akses VPS
• Login dengan username <code>root</code> dan password di atas
• VPS sudah ready untuk digunakan
• Jika ada masalah, silakan hubungi admin</blockquote>`,
            { parse_mode: "HTML" }
          );
          
          try {
            const testimoniText = `🖥️ *VPS BERHASIL DIBELI!*\n\n` +
              `👤 *Pembeli:* ${username}\n` +
              `🌐 *IP:* \`${data.ip}\`\n` +
              `📦 *Paket:* ${paket.toUpperCase()}\n` +
              `💾 *Spesifikasi:* ${productData.vpsData.plan}\n` +
              `💰 *Harga:* ${toRupiah(productData.vpsData.harga)}\n` +
              `🕒 *Waktu:* ${new Date().toLocaleString("id-ID")}\n\n` +
              `🎉 *Transaksi sukses!*`;
            
            await bot.telegram.sendMessage(config.testimoniChannel, testimoniText, {
              parse_mode: "Markdown",
              reply_markup: {
                inline_keyboard: [
                  [{ text: "🛒 Beli VPS", url: `https://t.me/${bot.botInfo.username}?start=shop` }]
                ]
              }
            });
          } catch (channelErr) {}
          
          try {
            await bot.telegram.sendMessage(
              config.ownerId,
              `<b>💰 VPS TERJUAL!</b>\n\n` +
              `<b>👤 Pembeli:</b> ${username} (${userId})\n` +
              `<b>🌐 IP VPS:</b> <code>${data.ip}</code>\n` +
              `<b>🔐 Password:</b> <code>${data.password}</code>\n` +
              `<b>📦 Paket:</b> ${paket.toUpperCase()}\n` +
              `<b>💰 Harga:</b> ${toRupiah(productData.vpsData.harga)}\n` +
              `<b>⏰ Waktu:</b> ${new Date().toLocaleString("id-ID")}`,
              { parse_mode: "HTML" }
            );
          } catch (ownerErr) {}
          
          const userName = `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim();
          sendTestimoniKeChannel(userName, userId, `VPS ${paket.toUpperCase()} - ${productData.vpsData.plan}`, productData.vpsData.harga);
          
        } else {
          await ctx.reply(`<blockquote>❌ <b>Gagal membuat VPS:</b> ${result.msg}</blockquote>`, { 
            parse_mode: "HTML" 
          });
          
          await ctx.reply(
`<blockquote>⚠️ <b>TRANSAKSI GAGAL</b>

Maaf, terjadi kesalahan saat membuat VPS Anda.

Silakan:
1. Hubungi admin untuk bantuan
2. Atau minta refund melalui admin
3. Admin akan membantu Anda segera</blockquote>`,
            { parse_mode: "HTML" }
          );
          
          try {
            await bot.telegram.sendMessage(
              config.ownerId,
              `<b>🚨 ERROR BUAT VPS!</b>\n\n` +
              `<b>👤 User:</b> ${username} (${userId})\n` +
              `<b>💰 Transaksi:</b> ${toRupiah(productData.vpsData.harga)}\n` +
              `<b>❌ Error:</b> ${result.msg}\n` +
              `<b>📦 Paket:</b> ${productData.vpsData.paket.toUpperCase()}\n` +
              `<b>💾 Plan:</b> ${productData.vpsData.plan}\n` +
              `<b>🌍 Region:</b> ${productData.vpsData.region}\n\n` +
              `<i>Silakan handle manual!</i>`,
              { parse_mode: "HTML" }
            );
          } catch (notifyErr) {}
        }
        
        if (userState[userId]?.vpsData) {
          delete userState[userId].vpsData;
        }
        
      } catch (error) {
        try {
          await ctx.deleteMessage(loadingMsg.message_id);
        } catch (e) {}
        
        await ctx.reply(`<blockquote>❌ <b>Error sistem VPS:</b> ${error.message}</blockquote>`, { 
          parse_mode: "HTML" 
        });
        
        try {
          await bot.telegram.sendMessage(
            config.ownerId,
            `<b>🚨 ERROR SISTEM VPS!</b>\n\n` +
            `<b>👤 User:</b> ${username} (${userId})\n` +
            `<b>❌ Error:</b> ${error.message}\n` +
            `<b>🔧 Stack:</b> <code>${error.stack || "No stack"}</code>\n\n` +
            `<i>Perlu penanganan manual!</i>`,
            { parse_mode: "HTML" }
          );
        } catch (notifyErr) {}
      }
    }
  } catch (error) {
    console.error("[ERROR] Error sending product:", error);
    safeReply(ctx, "<blockquote>❌ <b>Gagal mengirim produk.</b> Silakan hubungi owner.</blockquote>", { parse_mode: "HTML" });
  }
}

bot.on("photo", async (ctx) => {
  try {
    const userId = ctx.from.id;
    const state = userState[userId];
    
    if (state?.step === "PAYMENT_MANUAL_PENDING") {
      const photos = ctx.message.photo || [];
      if (photos.length === 0) {
        await ctx.reply("❌ Foto tidak ditemukan. Silakan kirim ulang.");
        return;
      }
      
      const bestPhoto = photos[photos.length - 1];
      
      const paymentData = {
        userId: userId,
        userName: `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim(),
        userUsername: ctx.from.username ? `@${ctx.from.username}` : '-',
        itemName: state.itemName,
        amount: state.amount,
        nominal: state.nominal,
        proofPhotoId: bestPhoto.file_id,
        timestamp: Date.now(),
        status: "pending",
        productData: state.productData
      };
      
      const payments = readManualPayments();
      const paymentIndex = payments.length;
      payments.push(paymentData);
      saveManualPayments(payments);
      
      delete userState[userId];
      
      try {
        await bot.telegram.sendPhoto(config.ownerId, paymentData.proofPhotoId, {
          caption: `<blockquote><b>🧾 BUKTI PEMBAYARAN MANUAL</b>\n\n<b>👤 User:</b> ${paymentData.userName}\n<b>🆔 ID:</b> ${paymentData.userId}\n<b>📛 Username:</b> ${paymentData.userUsername}\n\n<b>🛒 Item:</b> ${paymentData.itemName}\n<b>💰 Amount:</b> ${toRupiah(paymentData.amount)}\n<b>⏰ Time:</b> ${new Date(paymentData.timestamp).toLocaleString()}\n\n<i>Verifikasi pembayaran ini:</i></blockquote>`,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "✅ Terima & Kirim Produk", callback_data: `approve_payment_${paymentIndex}` },
                { text: "❌ Tolak", callback_data: `reject_payment_${paymentIndex}` }
              ]
            ]
          }
        });
        
        await ctx.reply("<blockquote>✅ <b>Bukti pembayaran telah dikirim ke owner!</b>\nSilakan tunggu verifikasi. Status akan diberitahu.</blockquote>", { parse_mode: "HTML" });
        
      } catch (ownerError) {
        console.error("[ERROR] Error sending to owner:", ownerError);
        await ctx.reply("<blockquote>❌ <b>Gagal mengirim bukti ke owner.</b> Silakan coba lagi atau hubungi owner langsung.</blockquote>", { parse_mode: "HTML" });
        userState[userId] = state;
      }
      
      return;
    }
    
  } catch (e) {
    console.error("[ERROR] Payment proof error:", e);
    try {
      await ctx.reply("<blockquote>❌ <b>Terjadi kesalahan saat memproses bukti pembayaran.</b> Silakan coba lagi.</blockquote>", { parse_mode: "HTML" });
    } catch (replyError) {
      console.error("[ERROR] Cannot send error message:", replyError);
    }
  }
});

bot.action(/approve_payment_(\d+)/, async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    await ctx.answerCbQuery("❌ Hanya owner yang boleh verifikasi!", { show_alert: true });
    return;
  }
  
  const paymentIndex = parseInt(ctx.match[1]);
  const payments = readManualPayments();
  const payment = payments[paymentIndex];
  
  if (!payment) {
    await ctx.answerCbQuery("❌ Pembayaran tidak ditemukan!", { show_alert: true });
    return;
  }
  
  if (payment.status !== "pending") {
    await ctx.answerCbQuery("❌ Pembayaran sudah diverifikasi!", { show_alert: true });
    return;
  }
  
  payment.status = "approved";
  payment.approvedBy = ctx.from.id;
  payment.approvedAt = Date.now();
  saveManualPayments(payments);
  
  try {
    await ctx.editMessageCaption(`<blockquote><b>✅ PEMBAYARAN DITERIMA</b>\n\n<b>👤 User:</b> ${payment.userName}\n<b>🛒 Item:</b> ${payment.itemName}\n<b>💰 Amount:</b> ${toRupiah(payment.amount)}\n<b>⏰ Approved:</b> ${new Date(payment.approvedAt).toLocaleString()}</blockquote>`,
      { parse_mode: "HTML" });
  } catch (e) {
    console.error("[ERROR] Failed to edit message caption:", e);
  }
  
  try {
    await bot.telegram.sendMessage(payment.userId, 
      `<blockquote><b>✅ Pembayaran Anda telah diterima!</b>\n\n<b>Item:</b> ${payment.itemName}\n<b>Amount:</b> ${toRupiah(payment.amount)}\n\n<i>Sedang mengirim produk...</i></blockquote>`,
      { parse_mode: "HTML" }
    );
    
    const fakeCtx = {
      from: { 
        id: payment.userId, 
        first_name: payment.userName.split(' ')[0] || payment.userName,
        last_name: payment.userName.split(' ').slice(1).join(' ') || ''
      },
      reply: (text, extra) => bot.telegram.sendMessage(payment.userId, text, extra),
      replyWithDocument: (file_id, extra) => bot.telegram.sendDocument(payment.userId, file_id, extra)
    };
    
    if (payment.productData) {
      await sendProductToUser(fakeCtx, payment.productData);
      
      sendTestimoniKeChannel(payment.userName, payment.userId, payment.itemName, payment.amount);
      
      await bot.telegram.sendMessage(config.ownerId,
        `<blockquote><b>📦 Produk telah dikirim ke user</b>\n\n<b>👤 User:</b> ${payment.userName}\n<b>🆔 ID:</b> ${payment.userId}\n<b>🛒 Item:</b> ${payment.itemName}\n<b>💰 Amount:</b> ${toRupiah(payment.amount)}</blockquote>`,
        { parse_mode: "HTML" }
      );
    }
    
    await ctx.answerCbQuery("✅ Pembayaran diterima dan produk dikirim!");
    
  } catch (error) {
    console.error("[ERROR] Error in payment approval:", error);
    await bot.telegram.sendMessage(config.ownerId, 
      `<blockquote><b>⚠️ Error saat memproses pembayaran untuk ${payment.userName} (${payment.userId}):</b> ${error.message}\n\n<i>Silakan kirim produk manual ke user.</i></blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});

bot.action(/reject_payment_(\d+)/, async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    await ctx.answerCbQuery("❌ Hanya owner yang boleh verifikasi!", { show_alert: true });
    return;
  }
  
  const paymentIndex = parseInt(ctx.match[1]);
  const payments = readManualPayments();
  const payment = payments[paymentIndex];
  
  if (!payment) {
    await ctx.answerCbQuery("❌ Pembayaran tidak ditemukan!", { show_alert: true });
    return;
  }
  
  if (payment.status !== "pending") {
    await ctx.answerCbQuery("❌ Pembayaran sudah diverifikasi!", { show_alert: true });
    return;
  }
  
  payment.status = "rejected";
  payment.rejectedBy = ctx.from.id;
  payment.rejectedAt = Date.now();
  saveManualPayments(payments);
  
  try {
    await ctx.editMessageCaption(`<blockquote><b>❌ PEMBAYARAN DITOLAK</b>\n\n<b>👤 User:</b> ${payment.userName}\n<b>🛒 Item:</b> ${payment.itemName}\n<b>💰 Amount:</b> ${toRupiah(payment.amount)}\n<b>⏰ Rejected:</b> ${new Date(payment.rejectedAt).toLocaleString()}</blockquote>`,
      { parse_mode: "HTML" });
  } catch (e) {
    console.error("[ERROR] Failed to edit message caption:", e);
  }
  
  try {
    await bot.telegram.sendMessage(payment.userId, 
      `<blockquote><b>❌ Pembayaran Anda ditolak!</b>\n\n<b>Alasan:</b> Bukti transfer tidak valid / nominal tidak sesuai.\n<i>Silakan hubungi owner untuk informasi lebih lanjut.</i></blockquote>`,
      { parse_mode: "HTML" }
    );
  } catch (e) {
    console.error("[ERROR] Failed to send rejection message to user:", e);
  }
  
  await ctx.answerCbQuery("❌ Pembayaran ditolak!");
});

bot.action("wd_rumahotp_start", async (ctx) => {
  if (ctx.from.id !== config.ownerId) return;

  const infoWd = config.wd_balance || {};

  userState[ctx.from.id] = { step: "WAITING_WD_RUMAHOTP_NOMINAL" };

  await editMenuMessage(ctx,
    `<blockquote><b>🏦 CAIRKAN RUMAHOTP (H2H)</b>\n\n` +
    `<b>Tujuan WD (Config):</b>\n` +
    `Bank: <code>${infoWd.bank_code || '-'}</code>\n` +
    `No: <code>${infoWd.destination_number || '-'}</code>\n` +
    `A/N: <code>${infoWd.destination_name || '-'}</code>\n\n` +
    `<i>Silakan ketik nominal yang ingin dicairkan (Angka saja).</i>\n` +
    `<i>Contoh: 50000</i></blockquote>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "❌ Batalkan", callback_data: "menu_owner" }]
        ]
      }
    }
  );
});

bot.command(["withdraw", "wd"], async (ctx) => {
  if (ctx.from.id !== config.ownerId) return;

  const args = ctx.message.text.split(" ");
  const nominal = parseInt(args[1]);

  if (!nominal || isNaN(nominal) || nominal < 1000) {
    return ctx.reply("<blockquote>💰 <b>Gunakan:</b> <code>/withdraw [nominal]</code>\nMinimal Rp 1.000</blockquote>", { parse_mode: "HTML" });
  }

  try {
    const waitMsg = await ctx.reply("⏳ <b>Memproses withdraw...</b>", { parse_mode: "HTML" });
    
    const atlConfig = {
      apiAtlantic: config.ApikeyAtlantic,
      wd_balance: config.wd_balance
    };

    const res = await atlanticTransfer(nominal, atlConfig);

    if (!res.status) throw new Error(res.message);

    const data = res.data;
    const caption = `<blockquote>✅ <b>PERMINTAAN WITHDRAW DIBUAT</b>\n\n` +
      `<b>Reff ID:</b> <code>${data.reff_id}</code>\n` +
      `<b>Transfer ID:</b> <code>${data.id}</code>\n` +
      `<b>Tujuan:</b> ${data.nomor_tujuan} (${data.nama})\n` +
      `<b>Nominal:</b> ${toRupiah(data.nominal)}\n` +
      `<b>Fee:</b> ${toRupiah(data.fee)}\n\n` +
      `<i>Menunggu konfirmasi transfer...</i></blockquote>`;

    await ctx.telegram.editMessageText(ctx.chat.id, waitMsg.message_id, null, caption, {
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("🔄 Cek Status WD", `check_wd_${data.id}`)]
      ])
    });

  } catch (err) {
    ctx.reply(`❌ <b>Error:</b> ${err.message}`, { parse_mode: "HTML" });
  }
});

bot.action(/check_wd_(.+)/, async (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("Bukan Owner!");
  const wdId = ctx.match[1];
  
  try {
    const res = await atlanticTransferStatus(wdId, config.ApikeyAtlantic);
    const status = res.data?.status || "processing";
    
    await ctx.answerCbQuery(`Status: ${status.toUpperCase()}`);
    
    if (status === "success") {
      await ctx.editMessageCaption(`<blockquote>✅ <b>WD BERHASIL!</b>\nID: <code>${wdId}</code>\nStatus: <b>SUCCESS</b></blockquote>`, { parse_mode: "HTML" });
    }
  } catch (e) {
    ctx.answerCbQuery("Gagal cek status.");
  }
});

bot.action("menu_wd_info", (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner yang bisa melihat info WD!", { show_alert: true });
  }
  
  function sensorString(input, visibleCount = 3, maskChar = 'X') {
    if (!input || input.length <= visibleCount) return input || "Tidak tersedia";
    const visiblePart = input.slice(0, visibleCount);
    const maskedPart = maskChar.repeat(input.length - visibleCount);
    return visiblePart + maskedPart;
  }
  
  function sensorWithSpace(str, visibleCount = 3, maskChar = 'X') {
    if (!str) return "Tidak tersedia";
    let result = '';
    let count = 0;
    for (let char of str) {
      if (char === ' ') {
        result += char;
      } else if (count < visibleCount) { 
        result += char; 
        count++; 
      } else {
        result += maskChar;
      }
    }
    return result;
  }
  
  const wdInfo = config.wd_balance || {};
  
  const infoText = `<blockquote><b>💰 INFO WITHDRAW</b>\n\n` +
    `<b>Bank/E-Wallet:</b> ${wdInfo.bank_code || "Belum diatur"}\n` +
    `<b>Tujuan:</b> ${sensorString(wdInfo.destination_number)}\n` +
    `<b>Nama:</b> ${sensorWithSpace(wdInfo.destination_name)}\n\n` +
    `Ketik <code>/withdraw [jumlah]</code> untuk menarik saldo.\n` +
    `<b>Contoh:</b> <code>/withdraw 50000</code>\n` +
    `<b>Minimal:</b> Rp 1.000</blockquote>`;
  
  ctx.editMessageText(infoText, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "🔙 Kembali", callback_data: "menu_owner" }]
      ]
    }
  }).catch(() => {
    ctx.reply(infoText, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 Kembali", callback_data: "menu_owner" }]
        ]
      }
    });
  });
  
  ctx.answerCbQuery();
});

bot.command("cancel", (ctx) => cancelTransaction(ctx));
bot.action("cancel_trx", (ctx) => cancelTransaction(ctx));
async function cancelTransaction(ctx) {
  const userId = ctx.from.id;
  
  if (activeTransactions[userId]) {
    try {
      if (activeTransactions[userId].messageId) {
        await ctx.deleteMessage(activeTransactions[userId].messageId).catch(() => {});
      }
    } catch (e) {}
    
    delete activeTransactions[userId];
    
    if (userState[userId]) {
      delete userState[userId];
    }
    
    await safeReply(ctx, "<blockquote>✅ <b>Transaksi dibatalkan.</b></blockquote>", { parse_mode: "HTML" });
  } else {
    await safeReply(ctx, "<blockquote>⚠️ <b>Tidak ada transaksi aktif.</b></blockquote>", { parse_mode: "HTML" });
  }
  
  if (ctx.updateType === 'callback_query') {
    try {
      await ctx.answerCbQuery();
    } catch (e) {}
  }
}

bot.command("ytsearch", async (ctx) => {
  const query = ctx.message.text.split(" ").slice(1).join(" ");
  if (!query) return safeReply(ctx, "<blockquote>❌ <b>Gunakan:</b> <code>/ytsearch judul lagu / keyword</code></blockquote>", { parse_mode: "HTML" });

  try {
    await safeReply(ctx, "<blockquote>🔍 <b>Mencari video di YouTube...</b></blockquote>", { parse_mode: "HTML" });

    const api = `https://api-ralzz.vercel.app/search/youtube?apikey=ubot&q=${encodeURIComponent(query)}`;
    const res = await axios.get(api);

    if (!res.data || !res.data.result || res.data.result.length === 0) {
      return safeReply(ctx, "<blockquote>❌ <b>Tidak ada hasil ditemukan.</b></blockquote>", { parse_mode: "HTML" });
    }

    const results = res.data.result.slice(0, 10); 

    results.forEach((vid, i) => {
      const text =
`<b>🎬 ${vid.title}</b>
<b>👤 Channel:</b> ${vid.author?.name || "-"}
<b>⏱ Durasi:</b> ${vid.duration?.timestamp || "-"}
<b>👁 Views:</b> ${vid.views?.toLocaleString() || "-"}

<b>🔗</b> ${vid.url}`;

      safeReply(ctx, text, { parse_mode: "HTML" });
    });

  } catch (err) {
    console.error(err);
    safeReply(ctx, "<blockquote>❌ <b>Error mengambil data pencarian YouTube.</b></blockquote>", { parse_mode: "HTML" });
  }
});

bot.command("ssweb", async (ctx) => {
  const url = ctx.message.text.split(" ")[1];
  if (!url) return safeReply(ctx, "<blockquote>❌ <b>Gunakan:</b> <code>/ssweb url</code></blockquote>", { parse_mode: "HTML" });

  try {
    safeReply(ctx, "<blockquote>⏳ <b>Mengambil screenshot...</b></blockquote>", { parse_mode: "HTML" });

    const api = `https://api-ralzz.vercel.app/tools/ssweb?apikey=ubot&url=${encodeURIComponent(url)}`;
    const res = await axios.get(api);

    if (!res.data || !res.data.result) {
      return safeReply(ctx, "<blockquote>❌ <b>Gagal mengambil screenshot.</b></blockquote>", { parse_mode: "HTML" });
    }

    await ctx.replyWithPhoto(res.data.result, {
      caption: "<blockquote>✅ <b>Screenshot berhasil!</b></blockquote>",
      parse_mode: "HTML"
    });

  } catch (err) {
    console.error(err);
    safeReply(ctx, "<blockquote>❌ <b>Error: tidak bisa mengambil screenshot.</b></blockquote>", { parse_mode: "HTML" });
  }
});

bot.command("makeqr", async(ctx) => {
  const txt = ctx.message.text.replace("/makeqr", "").trim();
  if (!txt) return safeReply(ctx, "<blockquote><b>Gunakan:</b> <code>/makeqr teks</code></blockquote>", { parse_mode: "HTML" });
  ctx.replyWithPhoto(`https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(txt)}`);
});

bot.command("tiktokmp4", async (ctx) => {
  const url = ctx.message.text.split(" ")[1];
  if (!url) return safeReply(ctx, "<blockquote>❌ <b>Gunakan:</b> <code>/tiktok url</code></blockquote>", { parse_mode: "HTML" });
  try {
    safeReply(ctx, "<blockquote>⏳ <b>Mengambil video TikTok...</b></blockquote>", { parse_mode: "HTML" });
    const res = await axios.get(`https://api-ralzz.vercel.app/download/tiktok?apikey=ubot&url=${encodeURIComponent(url)}`);
    if (!res.data.result.video_sd) return safeReply(ctx, "<blockquote>❌ <b>Gagal mengambil video!</b></blockquote>", { parse_mode: "HTML" });
    await ctx.replyWithVideo(res.data.video_sd, { caption: "<blockquote>✅ <b>TikTok Tanpa Watermark</b></blockquote>", parse_mode: "HTML" });
  } catch (e) { console.log(e); safeReply(ctx, "<blockquote>❌ <b>Error: tidak bisa download TikTok.</b></blockquote>", { parse_mode: "HTML" }); }
});

bot.command("ytmp3", async (ctx) => {
  const url = ctx.message.text.split(" ")[1];
  if (!url) return safeReply(ctx, "<blockquote><b>Gunakan:</b> <code>/ytmp3 url</code></blockquote>", { parse_mode: "HTML" });
  safeReply(ctx, "<blockquote>⏳ <b>Mengambil audio...</b></blockquote>", { parse_mode: "HTML" });
  try {
    const res = await axios.get(`https://api-ralzz.vercel.app/download/ytmp3v2?apikey=ubot&url=${encodeURIComponent(url)}`);
    await ctx.replyWithAudio(res.data.result, { caption: "<blockquote>🎵 <b>YouTube Audio Downloaded</b></blockquote>", parse_mode: "HTML" });
  } catch (e) { safeReply(ctx, "<blockquote>❌ <b>Gagal mengambil audio.</b></blockquote>", { parse_mode: "HTML" }); }
});

bot.command("shorten", async (ctx) => {
  const url = ctx.message.text.split(" ")[1];
  if (!url) return safeReply(ctx, "<blockquote><b>Gunakan:</b> <code>/shorten url</code></blockquote>", { parse_mode: "HTML" });
  try {
    const res = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
    safeReply(ctx, `<blockquote><b>🔗 Shortened URL:</b>\n${res.data}</blockquote>`, { parse_mode: "HTML" });
  } catch (e) { safeReply(ctx, "<blockquote>❌ <b>Gagal memendekkan URL.</b></blockquote>", { parse_mode: "HTML" }); }
});

bot.command("checkerror", async (ctx) => {
    if (!ctx.message.reply_to_message?.document)
        return safeReply(ctx, "<blockquote>❌ <b>Reply file untuk dianalisa!</b></blockquote>", { parse_mode: "HTML" });

    const file = ctx.message.reply_to_message.document;
    const fileId = file.file_id;
    const fileName = file.file_name;

    const limit = updateUserLimit(ctx.from.id);
    if (limit < 0) return safeReply(ctx, "<blockquote>❌ <b>Limit habis!</b> Upgrade ke premium.</blockquote>", { parse_mode: "HTML" });

    try {
        safeReply(ctx, "<blockquote>📥 <b>Mengunduh & menganalisa file...</b></blockquote>", { parse_mode: "HTML" });

        const buff = await downloadFile(fileId);
        const content = getFileContent(buff);

        const analysis = await analyzeErrorWithGemini(content, fileName);

        safeReply(ctx, `<b>📄 Hasil Analisis:</b>\n\n${analysis}\n\n<b>Sisa limit:</b> ${getUserLimit(ctx.from.id)}`,
            { parse_mode: "HTML" }
        );
    } catch (err) {
        safeReply(ctx, "<blockquote>❌ <b>Error:</b></blockquote>" + err.message, { parse_mode: "HTML" });
    }
});

bot.command("fixerror", async (ctx) => {
    if (!ctx.message.reply_to_message?.document)
        return safeReply(ctx, "❌ <b>Reply file untuk diperbaiki!</b>", { parse_mode: "HTML" });

    const file = ctx.message.reply_to_message.document;
    const fileId = file.file_id;
    const fileName = file.file_name;

    const limit = updateUserLimit(ctx.from.id);
    if (limit < 0) return safeReply(ctx, "❌ <b>Limit habis!</b> Upgrade ke premium.", { parse_mode: "HTML" });

    try {
        safeReply(ctx, "🔧 <b>Memperbaiki error dengan Gemini...</b>", { parse_mode: "HTML" });

        const buff = await downloadFile(fileId);
        const content = getFileContent(buff);

        const fixed = await fixErrorWithGemini(content, fileName);

        ctx.replyWithDocument(
            { source: Buffer.from(fixed), filename: `fixed_${fileName}` },
            { caption: `✔ <b>Error berhasil diperbaiki!</b>\n<b>Sisa limit:</b> ${getUserLimit(ctx.from.id)}`, parse_mode: "HTML" }
        );
    } catch (err) {
        safeReply(ctx, "❌ <b>Error:</b> " + err.message, { parse_mode: "HTML" });
    }
});

bot.command("qc", async (ctx) => {
  try {
    const reply = ctx.message.reply_to_message;

    if (!reply) {
      return ctx.reply(
        "❌ <b>Contoh penggunaan:</b> <code>/qc (reply pesan)</code>",
        { parse_mode: "HTML" }
      );
    }

    const target = reply.forward_from || reply.from;
    const username = target.first_name || "User";

    let avatarUrl = "https://files.catbox.moe/nwvkbt.png";

    try {
      const photos = await ctx.telegram.getUserProfilePhotos(target.id, 0, 1);

      if (photos.total_count > 0) {
        const file = await ctx.telegram.getFileLink(photos.photos[0][0].file_id);
        avatarUrl = file.href;
      }
    } catch (err) {
      console.log("Avatar fetch error:", err);
    }

    const messageText = reply.text || reply.caption || "(pesan tidak berisi teks)";

    const payload = {
      type: "quote",
      format: "png",
      backgroundColor: "#000000",
      width: 512,
      height: 768,
      scale: 2,
      messages: [
        {
          entities: [],
          avatar: true,
          from: {
            id: target.id,
            name: username,
            photo: { url: avatarUrl },
          },
          text: messageText,
          replyMessage: {},
        },
      ],
    };

    const loading = await ctx.reply(
      `<blockquote>⏳ <b>Membuat sticker quote...</b></blockquote>`,
      { parse_mode: "HTML" }
    );

    const result = await axios.post(
      "https://bot.lyo.su/quote/generate",
      payload,
      { headers: { "Content-Type": "application/json" } }
    );

    const buffer = Buffer.from(result.data.result.image, "base64");

    await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id);

    await ctx.replyWithSticker({ source: buffer });
  } catch (err) {
    console.error("QC ERROR:", err);
    return ctx.reply(
      `<blockquote>❌ <b>Terjadi kesalahan saat membuat sticker.</b></blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});

bot.command("brat", async (ctx) => {
  const text = ctx.message.text.split(" ").slice(1).join(" ");

  if (!text) {
    return ctx.reply("❌ <b>Contoh:</b> <code>/brat (kata-kata)</code>", {
      parse_mode: "HTML"
    });
  }

  const chatId = ctx.chat.id;
  const tempFilePath = "./brat_temp.webp";

  try {
    await ctx.reply("<blockquote>⏳ <b>Membuat sticker, tunggu sebentar...</b></blockquote>", { parse_mode: "HTML" });

    const imageUrl = `https://kepolu-brat.hf.space/brat?q=${encodeURIComponent(text)}`;

    const downloadFile = async (url, dest) => {
      const writer = fs.createWriteStream(dest);

      const response = await axios({
        url,
        method: "GET",
        responseType: "stream",
      });

      response.data.pipe(writer);

      return new Promise((resolve, reject) => {
        writer.on("finish", resolve);
        writer.on("error", reject);
      });
    };

    await downloadFile(imageUrl, tempFilePath);

    await ctx.replyWithSticker({ source: tempFilePath });

    fs.unlinkSync(tempFilePath);

  } catch (err) {
    console.error(err);
    ctx.reply("<blockquote>❌ <b>Terjadi kesalahan saat membuat sticker. Coba lagi nanti.</b></blockquote>", { parse_mode: "HTML" });
  }
});

async function uploadToCatbox(buffer, filename) {
  try {
    const form = new FormData();
    form.append('fileToUpload', buffer, { filename: filename });
    form.append('reqtype', 'fileupload');
    
    const response = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: {
        ...form.getHeaders()
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Upload error:', error);
    throw error;
  }
}


bot.command("tourl", async (ctx) => {
  try {
    const chatId = ctx.chat.id;
    const userId = ctx.from.id;

    const replyMsg = ctx.message.reply_to_message;
    if (!replyMsg) {
      return ctx.reply(
        `<blockquote>❌ <b>Balas sebuah pesan yang berisi file/audio/video dengan perintah /tourl</b></blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    if (
      !replyMsg.document &&
      !replyMsg.photo &&
      !replyMsg.video &&
      !replyMsg.audio &&
      !replyMsg.voice
    ) {
      return ctx.reply(
        `<blockquote>❌ <b>Pesan yang kamu balas tidak mengandung file/audio/video yang bisa diupload.</b></blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    let fileId, filename;

    if (replyMsg.document) {
      fileId = replyMsg.document.file_id;
      filename = replyMsg.document.file_name;
    } else if (replyMsg.photo) {
      const photoArray = replyMsg.photo;
      fileId = photoArray[photoArray.length - 1].file_id;
      filename = "photo.jpg";
    } else if (replyMsg.video) {
      fileId = replyMsg.video.file_id;
      filename = replyMsg.video.file_name || "video.mp4";
    } else if (replyMsg.audio) {
      fileId = replyMsg.audio.file_id;
      filename = replyMsg.audio.file_name || "audio.mp3";
    } else if (replyMsg.voice) {
      fileId = replyMsg.voice.file_id;
      filename = "voice.ogg";
    }

    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${config.botToken}/${file.file_path}`;

    const res = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const buffer = Buffer.from(res.data);

    const catboxUrl = await uploadToCatbox(buffer, filename);

    await ctx.reply(
      `<blockquote>✅ <b>File berhasil diupload ke Catbox:</b>\n<code>${catboxUrl}</code></blockquote>`,
      { parse_mode: "HTML" }
    );
  } catch (err) {
    console.error("tourl error:", err);
    
    const cleanError = err.message.replace(/</g, '&lt;').replace(/>/g, '&gt;');
    
    ctx.reply(
      `<blockquote>❌ <b>Gagal upload file:</b> ${cleanError}</blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});

function calcTotalPrice(basePrice, qty) {
  if (qty <= 1) return basePrice;
  return basePrice * qty;
}

function renderPurchaseText(app, qty, total) {
  const stock = (app.accounts || []).length;
  return `<b>• Produk :</b> ${app.nama}
<b>• Sisa Stok :</b> ${stock}
<b>• Deskripsi :</b> ${app.deskripsi || '-'}

──────────────

<b>• Jumlah :</b> ${qty}
<b>• Harga Satuan :</b> ${toRupiah(app.harga)}
<b>• Total Harga :</b> ${toRupiah(total)}

<i>Updated: ${new Date().toLocaleTimeString()}</i>`;
}

bot.catch((err, ctx) => {
    console.error("Bot Error:", err);
    safeReply(ctx, "<blockquote>❌ <b>Terjadi kesalahan.</b></blockquote>", { parse_mode: "HTML" });
});

bot.launch().then(() => {
  console.log("🤖 Bot Berjalan!");
  
  setTimeout(() => {
    console.log("[INFO] Mengirim backup startup ke owner...");
    createAndSendFullBackup(null, true);
  }, 10000);

  const INTERVAL_BACKUP = 2 * 60 * 60 * 1000; 
  
  setInterval(() => {
    console.log("[INFO] Menjalankan Auto Backup Berkala...");
    createAndSendFullBackup(null, true);
  }, INTERVAL_BACKUP);
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));