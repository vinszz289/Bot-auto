module.exports = {
    // --- TELEGRAM SETTINGS ---
    botToken: "8418052126:AAEiQoBh36I9-ceYgjlHR4oQJgzU9sXAXKM",
    ownerId: 7820017829,
    ownerName: "VINSZ",
    ownerWa: "https://wa.me/",
    ownerUser: "@Vinszvvip",
    botName: "autoordervinsz_bot",
    startPhoto:"https://h.top4top.io/p_3668g797a0.jpg",
    startAudio: "-",
    startAudioCaption: "Welcome To VINSZVIP",
    testimoniChannel: "@vinszviip",

    
    // --- Nokos Setting ( Rumah Otp )
    RUMAHOTP: "otp_sniYLZiYvzxjJYMr",
    UNTUNG_NOKOS: 150,
    UNTUNG_DEPOSIT: 500,
    ppthumb: "https://b.top4top.io/p_3668d819x0.jpg",

    // --- PAYMENT ORKUT ---
    payment: {
        apikey: "ubot",
        username: "",
        token: ":"
    },

    // --- PAYMENT ATLANTIC ---
    ApikeyAtlantic: "",
    wd_balance: {
        bank_code: "DANA", // DANA, BCA, BRI, dll
        destination_number: "083833247153",
        destination_name: "SITI",
    },
    
    // --- Qris Manual Setting ---
    manualQrisPhoto: "https://files.catbox.moe/01t62d.jpg",
    
    // --- Vps Setting ---
    ApiDO1: "dop_v1_a3c011d5395a7cf9f4a9a78a2cb852bce4db7d29adea73704ee5a39ce65f2262", // ganti api do lu
    hargaVPS: {
       low: {
        "2c2": 5000,
        "4c2": 5000,
        "8c4": 5000,
        "16c4": 6000,
        "16c8": 6000
      },
       medium: {
        "2c2": 15000,
        "4c2": 20000,
        "8c4": 25000,
        "16c4": 30000,
        "16c8": 35000
      },
       high: {
        "2c2": 40000,
        "4c2": 50000,
        "8c4": 60000,
        "16c4": 70000,
        "16c8": 80000
    }
  },
    // --- Fix Error Setting
    USER_LIMIT: 3,
    GEMINI_API_KEY: "AIzaSyB47adRUMkO-Yn_MOcOZBDV0PFIpzqKBy4",
    
    // --- PTERODACTYL PANEL ---
    panel: {
        domain: "https://ceocpanel.kinzprivat.biz.id",
        apikey: "ptla_KGMzLa87YMCAAtn851PIqNoqxefsAaq3FNtH7Mjt4SG",
        nestId: 5,
        eggId: 15,
        locationId: 1,
        startup: "npm start",
        image: "ghcr.io/parkervcp/yolks:nodejs_18"
    },

    // --- HARGA PANEL ---
    hargaPanel: {
        unlimited: 12000,
        perGB: 1000,  
    }
};